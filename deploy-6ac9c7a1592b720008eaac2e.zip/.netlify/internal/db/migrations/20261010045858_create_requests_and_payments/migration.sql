CREATE TABLE "book_requests" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"title" text NOT NULL,
	"author" text,
	"isbn" text,
	"edition" text,
	"year" integer,
	"category" text,
	"condition" text DEFAULT 'Any' NOT NULL,
	"max_budget" integer NOT NULL,
	"city" text,
	"notes" text,
	"tier" text NOT NULL,
	"status" text NOT NULL,
	"premium_activated_at" timestamp with time zone,
	"deadline" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "book_requests_tier_check" CHECK (tier in ('Free', 'Premium')),
	CONSTRAINT "book_requests_status_check" CHECK (status in ('Draft', 'Awaiting Payment', 'Payment Failed', 'Searching', 'Seller Responses Received', 'Offer Selected', 'Completed', 'No Match', 'Cancelled', 'Refund Pending', 'Refunded')),
	CONSTRAINT "book_requests_budget_check" CHECK (max_budget > 0)
);
--> statement-breakpoint
CREATE TABLE "payment_events" (
	"event_id" text PRIMARY KEY,
	"type" text NOT NULL,
	"gateway_order_id" text,
	"payload" jsonb NOT NULL,
	"received_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid(),
	"request_id" uuid NOT NULL,
	"mode" text NOT NULL,
	"amount" integer NOT NULL,
	"currency" text DEFAULT 'INR' NOT NULL,
	"status" text DEFAULT 'created' NOT NULL,
	"gateway_order_id" text NOT NULL UNIQUE,
	"gateway_payment_id" text UNIQUE,
	"failure_reason" text,
	"verified_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "payments_status_check" CHECK (status in ('created', 'pending', 'paid', 'failed', 'refunded')),
	CONSTRAINT "payments_mode_check" CHECK (mode in ('razorpay_test', 'razorpay_live', 'mock')),
	CONSTRAINT "payments_amount_check" CHECK (amount > 0)
);
--> statement-breakpoint
CREATE INDEX "book_requests_status_idx" ON "book_requests" ("status");--> statement-breakpoint
CREATE INDEX "payments_request_idx" ON "payments" ("request_id");--> statement-breakpoint
ALTER TABLE "payments" ADD CONSTRAINT "payments_request_id_book_requests_id_fkey" FOREIGN KEY ("request_id") REFERENCES "book_requests"("id") ON DELETE CASCADE;