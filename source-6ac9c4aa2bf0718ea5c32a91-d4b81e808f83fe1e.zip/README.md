# StudySwap

StudySwap is a student-to-student marketplace for buying, selling and reusing second-hand JEE, NEET,
UPSC, CAT and college books. Sellers don't type a price: StudySwap recommends a fair one and the
seller agrees to it before publishing. A Premium Book Finder helps students track down books nobody
has listed yet.

## What's live now

- **Home** – hero search, exam categories, featured and recent listings, AI-pricing explainer, Premium
  Book Finder promo, an interactive savings calculator and how-it-works.
- **Browse Books** (`/books`) – search by title/author/ISBN/keyword, filter by category, condition,
  location, edition and max price, sort by relevance/price/newest. Filters live in the URL.
- **Book details** (`/books/:id`) – AI price, range, confidence, pricing factors, estimated savings,
  consent-based contact and report flows.
- **Sell a Book** (`/sell`) – validated listing form with photo checks, AI price review (preview
  engine), pricing history, and an explicit "accept & publish" consent step.
- **Find a Book** (`/find`) – Free vs Premium request, fee/matching-period/refund disclosure, and live
  matching against listings.
- **My Dashboard**, **Log in**, and contact/privacy/terms/refund pages.

All listings, sellers, requests and offers are **sample data** from `src/data/fixtures.ts` and are labelled
as such in the UI. Nothing is saved yet, no payments are taken, and the price review uses a rule-based
preview engine instead of the AI model.

## Tech

TanStack Start (React 19, Vite 7, TypeScript), Tailwind CSS 4, lucide-react icons, deployed on Netlify.
Planned: Netlify Database (Postgres + Drizzle), Netlify Identity, Netlify Blobs, Netlify AI Gateway, Razorpay.

## Run locally

```bash
pnpm install
netlify dev        # or: pnpm dev  (http://localhost:3000)
```

## Roadmap

See [PLAN.md](./PLAN.md): data model → accounts → real marketplace → AI pricing → Book Finder & matching →
Razorpay payments → notifications → admin → tests.

## Integrations checklist

| Integration | Status |
|---|---|
| Database (Netlify Database) | Not yet configured (milestone 2) |
| Auth (Netlify Identity) | Not yet configured (milestone 3) |
| Image storage (Netlify Blobs) | Not yet configured (milestone 4) |
| AI pricing (Netlify AI Gateway) | Not yet configured (milestone 5) |
| Razorpay (test mode) | Needs Razorpay test keys (milestone 7) |
| Email notifications | Needs an email provider (milestone 8) |
