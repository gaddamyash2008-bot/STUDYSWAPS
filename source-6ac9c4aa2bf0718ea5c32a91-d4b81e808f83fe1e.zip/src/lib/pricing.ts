import { listings, type Condition, type Confidence } from '@/data/fixtures'

export const inr = (n: number) =>
  '₹' + Math.round(n).toLocaleString('en-IN')

export interface Savings {
  savings: number
  discountPct: number
  /** true when the price is above the original or discount looks implausible */
  needsReview: boolean
}

/** Savings = Original − Recommended; Discount % = Savings ÷ Original × 100 */
export function calculateSavings(originalPrice: number, sellingPrice: number): Savings | null {
  if (!(originalPrice > 0) || !(sellingPrice > 0)) return null
  const savings = originalPrice - sellingPrice
  const discountPct = (savings / originalPrice) * 100
  return {
    savings,
    discountPct,
    needsReview: sellingPrice > originalPrice || discountPct > 92,
  }
}

export interface PricingInput {
  title: string
  author: string
  isbn?: string
  edition: string
  publicationYear: number
  originalPrice: number
  condition: Condition
  wear: string
}

export interface PricingPreview {
  recommended: number
  range: [number, number]
  confidence: Confidence
  evidence: 'market' | 'estimated'
  comparableCount: number
  factors: Array<string>
}

const conditionFactor: Record<Condition, number> = {
  'Like New': 0.62,
  Good: 0.52,
  Acceptable: 0.4,
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '')

/**
 * Deterministic preview of the pricing engine, used by the UI until the
 * server-side AI assessment exists (PLAN.md milestone 5). This also becomes
 * the transparent fallback when the AI or market evidence is unavailable.
 * It only cites comparables that actually exist in the listings data.
 */
export function previewPrice(input: PricingInput): PricingPreview {
  const year = new Date().getFullYear()
  const age = Math.max(0, year - input.publicationYear)
  const factors: Array<string> = []

  let ratio = conditionFactor[input.condition]
  factors.push(`${input.condition} condition`)

  const agePenalty = Math.min(age * 0.025, 0.15)
  if (agePenalty > 0) {
    ratio -= agePenalty
    factors.push(`Edition is ${age} year${age === 1 ? '' : 's'} old`)
  } else {
    factors.push('Current or very recent edition')
  }

  if (/torn|missing|water|loose|damage/i.test(input.wear)) {
    ratio -= 0.08
    factors.push('Reported damage lowers the price')
  }

  const comps = listings.filter(
    (l) =>
      (input.isbn && l.isbn && norm(l.isbn) === norm(input.isbn)) ||
      (norm(l.title).includes(norm(input.title).slice(0, 12)) && norm(input.title).length > 3),
  )

  let recommended = input.originalPrice * Math.max(ratio, 0.2)
  if (comps.length > 0) {
    const avgRatio = comps.reduce((s, c) => s + c.price / c.originalPrice, 0) / comps.length
    recommended = (recommended + input.originalPrice * avgRatio) / 2
    factors.unshift(`${comps.length} comparable StudySwap listing${comps.length === 1 ? '' : 's'} found`)
  } else {
    factors.unshift('No comparable listings yet — this is an estimate')
  }

  // Safeguards: positive, rounded to ₹10, never above 85% of original.
  recommended = Math.min(recommended, input.originalPrice * 0.85)
  recommended = Math.max(10, Math.round(recommended / 10) * 10)
  const spread = comps.length >= 3 ? 0.08 : 0.15

  return {
    recommended,
    range: [
      Math.max(10, Math.round((recommended * (1 - spread)) / 10) * 10),
      Math.round((recommended * (1 + spread)) / 10) * 10,
    ],
    confidence: comps.length >= 3 ? 'High' : comps.length >= 1 ? 'Medium' : 'Low',
    evidence: comps.length > 0 ? 'market' : 'estimated',
    comparableCount: comps.length,
    factors,
  }
}
