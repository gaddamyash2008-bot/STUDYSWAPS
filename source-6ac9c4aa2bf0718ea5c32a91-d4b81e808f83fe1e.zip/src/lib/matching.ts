import { listings, type CategoryId, type Condition, type Listing } from '@/data/fixtures'

export interface RequestCriteria {
  title: string
  author?: string
  isbn?: string
  edition?: string
  category?: CategoryId | ''
  condition?: Condition | 'Any'
  maxBudget?: number
  city?: string
}

export interface Match {
  listing: Listing
  score: number
  reasons: Array<string>
}

const normalize = (s = '') =>
  s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim()

const tokens = (s = '') => new Set(normalize(s).split(' ').filter((t) => t.length > 2))

function jaccard(a: Set<string>, b: Set<string>) {
  if (!a.size || !b.size) return 0
  let inter = 0
  a.forEach((t) => b.has(t) && inter++)
  return inter / (a.size + b.size - inter)
}

const conditionRank: Record<Condition, number> = { 'Like New': 3, Good: 2, Acceptable: 1 }

/** Scores active listings against a request. Exact ISBN matches rank first. */
export function findMatches(c: RequestCriteria): Array<Match> {
  const out: Array<Match> = []
  for (const l of listings) {
    if (l.status !== 'Active') continue
    const reasons: Array<string> = []
    let score = 0

    const isbnHit = c.isbn && l.isbn && c.isbn.replace(/\D/g, '') === l.isbn.replace(/\D/g, '')
    if (isbnHit) {
      score += 100
      reasons.push('Exact ISBN match')
    }

    const titleSim = jaccard(tokens(c.title), tokens(l.title))
    if (titleSim > 0) {
      score += titleSim * 60
      if (titleSim >= 0.5) reasons.push('Title match')
    }
    if (c.author && jaccard(tokens(c.author), tokens(l.author)) > 0) {
      score += 15
      reasons.push('Same author')
    }
    if (c.edition && normalize(l.edition).includes(normalize(c.edition))) {
      score += 10
      reasons.push('Edition matches')
    }
    if (!isbnHit && titleSim < 0.25) continue

    if (c.category && l.category === c.category) score += 5
    if (c.condition && c.condition !== 'Any') {
      if (conditionRank[l.condition] >= conditionRank[c.condition]) {
        score += 5
        reasons.push(`${l.condition} meets preference`)
      } else score -= 10
    }
    if (c.maxBudget && c.maxBudget > 0) {
      if (l.price <= c.maxBudget) {
        score += 8
        reasons.push('Within budget')
      } else score -= 15
    }
    if (c.city && normalize(l.city) === normalize(c.city)) {
      score += 6
      reasons.push(`In ${l.city}`)
    }
    out.push({ listing: l, score, reasons })
  }
  return out.sort((a, b) => b.score - a.score)
}
