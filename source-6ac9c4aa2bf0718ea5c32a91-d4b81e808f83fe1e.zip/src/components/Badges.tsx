import { ShieldCheck, Sparkles, AlertTriangle } from 'lucide-react'
import type { Condition, Confidence } from '@/data/fixtures'

export function ConditionBadge({ condition }: { condition: Condition }) {
  const cls =
    condition === 'Like New'
      ? 'bg-forest-soft text-forest'
      : condition === 'Good'
        ? 'bg-marigold-soft text-[#8a5a10]'
        : 'bg-paper-deep text-ink-soft'
  return <span className={`chip ${cls}`}>{condition}</span>
}

export function ConfidenceBadge({
  confidence,
  evidence,
}: {
  confidence: Confidence
  evidence: 'market' | 'estimated'
}) {
  if (evidence === 'estimated' || confidence === 'Low')
    return (
      <span className="chip bg-brick-soft text-brick" title="Little or no comparable data — treat as an estimate">
        <AlertTriangle size={12} /> Estimated · low confidence
      </span>
    )
  return (
    <span className="chip bg-forest-soft text-forest" title="Backed by comparable StudySwap listings">
      {confidence === 'High' ? <ShieldCheck size={12} /> : <Sparkles size={12} />} AI price · {confidence.toLowerCase()} confidence
    </span>
  )
}

export function SampleTag() {
  return (
    <span className="chip border border-dashed border-ink-soft/40 bg-transparent text-ink-soft">Sample data</span>
  )
}
