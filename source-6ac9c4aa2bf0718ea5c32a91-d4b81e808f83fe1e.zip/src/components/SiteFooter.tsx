import { Link } from '@tanstack/react-router'
import { Logo } from './Logo'

export function SiteFooter() {
  return (
    <footer className="mt-24 bg-forest-dark text-paper/80">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo light />
          <p className="mt-4 max-w-sm text-sm leading-relaxed">
            A student-to-student marketplace for second-hand academic and competitive-exam books.
            Fair, AI-recommended prices and help finding the books you can't locate.
          </p>
        </div>
        <div>
          <h3 className="font-sans text-sm font-bold uppercase tracking-wider text-paper">Marketplace</h3>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link to="/books" className="hover:text-marigold">Browse books</Link></li>
            <li><Link to="/sell" className="hover:text-marigold">Sell a book</Link></li>
            <li><Link to="/find" className="hover:text-marigold">Premium Book Finder</Link></li>
            <li><Link to="/dashboard" className="hover:text-marigold">My dashboard</Link></li>
          </ul>
        </div>
        <div>
          <h3 className="font-sans text-sm font-bold uppercase tracking-wider text-paper">Policies</h3>
          <ul className="mt-4 space-y-2 text-sm">
            <li><Link to="/legal/$page" params={{ page: 'contact' }} className="hover:text-marigold">Contact</Link></li>
            <li><Link to="/legal/$page" params={{ page: 'privacy' }} className="hover:text-marigold">Privacy policy</Link></li>
            <li><Link to="/legal/$page" params={{ page: 'terms' }} className="hover:text-marigold">Terms of use</Link></li>
            <li><Link to="/legal/$page" params={{ page: 'refunds' }} className="hover:text-marigold">Refund policy</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <p className="mx-auto max-w-7xl px-5 py-5 text-xs text-paper/60">
          © {new Date().getFullYear()} StudySwap. Listings shown in this preview are sample data.
        </p>
      </div>
    </footer>
  )
}
