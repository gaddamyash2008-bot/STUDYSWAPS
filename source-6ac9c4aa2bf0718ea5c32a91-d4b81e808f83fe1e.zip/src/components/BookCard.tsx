import { Link } from '@tanstack/react-router'
import { MapPin } from 'lucide-react'
import type { Listing } from '@/data/fixtures'
import { calculateSavings, inr } from '@/lib/pricing'
import { BookCover } from './BookCover'
import { ConditionBadge } from './Badges'

export function BookCard({ book }: { book: Listing }) {
  const s = calculateSavings(book.originalPrice, book.price)
  return (
    <Link
      to="/books/$bookId"
      params={{ bookId: book.id }}
      className="group card flex flex-col p-3 transition hover:-translate-y-0.5 hover:border-forest/40 hover:shadow-lg"
    >
      <div className="relative">
        <BookCover title={book.title} author={book.author} category={book.category} />
        {s && s.savings > 0 && (
          <span className="absolute right-2 top-2 rounded-full bg-marigold px-2 py-0.5 text-xs font-bold text-ink shadow">
            −{Math.round(s.discountPct)}%
          </span>
        )}
        {book.status === 'Reserved' && (
          <span className="absolute inset-x-2 bottom-2 rounded-md bg-ink/80 py-1 text-center text-xs font-semibold text-white">
            Reserved
          </span>
        )}
      </div>
      <div className="flex flex-1 flex-col px-1 pt-3">
        <h3 className="font-sans text-sm font-semibold leading-snug text-ink group-hover:text-forest line-clamp-2">
          {book.title}
        </h3>
        <p className="mt-0.5 text-xs text-ink-soft">
          {book.author} · {book.edition}
        </p>
        <div className="mt-2 flex items-center gap-2">
          <ConditionBadge condition={book.condition} />
          <span className="flex items-center gap-0.5 text-xs text-ink-soft">
            <MapPin size={11} /> {book.city}
          </span>
        </div>
        <div className="mt-auto flex items-baseline gap-2 pt-3">
          <span className="text-lg font-bold text-ink">{inr(book.price)}</span>
          <span className="text-xs text-ink-soft line-through">{inr(book.originalPrice)}</span>
        </div>
      </div>
    </Link>
  )
}
