import { getCategory, type CategoryId } from '@/data/fixtures'

/** Typographic cover placeholder until seller photos are uploaded. */
export function BookCover({
  title,
  author,
  category,
  size = 'md',
}: {
  title: string
  author: string
  category: CategoryId
  size?: 'sm' | 'md' | 'lg'
}) {
  const cat = getCategory(category)
  const pad = size === 'lg' ? 'p-8' : size === 'sm' ? 'p-3' : 'p-5'
  const titleSize = size === 'lg' ? 'text-3xl' : size === 'sm' ? 'text-sm' : 'text-lg'
  return (
    <div
      className={`relative flex aspect-[3/4] w-full flex-col justify-between overflow-hidden rounded-lg ${pad} text-white shadow-[inset_6px_0_0_rgba(0,0,0,0.18),0_8px_20px_-8px_rgba(29,42,36,0.5)]`}
      style={{ background: `linear-gradient(155deg, ${cat.color}, ${cat.color}dd 60%, #00000055)` }}
    >
      <div className="absolute inset-y-0 left-2.5 w-px bg-white/25" />
      <span className="self-start rounded-full bg-white/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-widest">
        {cat.name}
      </span>
      <div>
        <p className={`font-display font-semibold leading-tight ${titleSize} line-clamp-4`}>{title}</p>
        <p className="mt-2 text-xs text-white/75 line-clamp-1">{author}</p>
      </div>
    </div>
  )
}
