import { Link } from '@tanstack/react-router'

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2" aria-label="StudySwap home">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
        <rect x="3" y="6" width="11" height="20" rx="2" fill={light ? '#f7f3ea' : '#1f4d3a'} />
        <rect x="18" y="6" width="11" height="20" rx="2" fill="#f2a93b" />
        <path d="M10 13h12l-3-3M22 19H10l3 3" stroke={light ? '#1f4d3a' : '#fffdf8'} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className={`font-display text-xl font-bold ${light ? 'text-paper' : 'text-ink'}`}>
        Study<span className="text-marigold">Swap</span>
      </span>
    </Link>
  )
}
