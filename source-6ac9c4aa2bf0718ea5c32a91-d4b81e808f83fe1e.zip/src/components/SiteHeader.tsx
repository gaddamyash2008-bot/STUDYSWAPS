import { useState } from 'react'
import { Link } from '@tanstack/react-router'
import { Menu, X, UserRound } from 'lucide-react'
import { Logo } from './Logo'

const nav = [
  { to: '/', label: 'Home' },
  { to: '/books', label: 'Browse Books' },
  { to: '/sell', label: 'Sell a Book' },
  { to: '/find', label: 'Find a Book' },
  { to: '/dashboard', label: 'My Dashboard' },
] as const

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-40 border-b border-line/70 bg-paper/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <Logo />
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {nav.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              activeOptions={{ exact: n.to === '/' }}
              className="rounded-full px-3.5 py-2 text-sm font-medium text-ink-soft transition hover:text-ink"
              activeProps={{ className: 'bg-forest-soft !text-forest font-semibold' }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/login" className="btn-ghost hidden !py-2 sm:inline-flex">
            <UserRound size={16} /> Log in
          </Link>
          <button
            type="button"
            className="rounded-full p-2 lg:hidden"
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="border-t border-line bg-paper px-5 py-3 lg:hidden" aria-label="Mobile">
          {[...nav, { to: '/login', label: 'Log in / Profile' } as const].map((n) => (
            <Link
              key={n.to}
              to={n.to}
              onClick={() => setOpen(false)}
              activeOptions={{ exact: n.to === '/' }}
              className="block rounded-xl px-3 py-2.5 font-medium text-ink-soft"
              activeProps={{ className: 'bg-forest-soft !text-forest' }}
            >
              {n.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  )
}
