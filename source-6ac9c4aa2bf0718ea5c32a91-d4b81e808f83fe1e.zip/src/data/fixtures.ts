/**
 * SAMPLE / DEMO DATA.
 *
 * Every listing, seller and request in this file is fictional and exists only
 * to demonstrate the StudySwap interface. Replace these fixtures with real
 * Netlify Database queries in the data-model milestone (see PLAN.md).
 */

export type CategoryId = 'jee' | 'neet' | 'upsc' | 'cat' | 'college' | 'other'
export type Condition = 'Like New' | 'Good' | 'Acceptable'
export type Exchange = 'Shipping' | 'In-person' | 'Shipping or in-person'
export type Confidence = 'High' | 'Medium' | 'Low'
export type ListingStatus =
  | 'Draft'
  | 'Awaiting Price Review'
  | 'Active'
  | 'Reserved'
  | 'Sold'
  | 'Removed'

export interface Category {
  id: CategoryId
  name: string
  blurb: string
  color: string
}

export const categories: Array<Category> = [
  { id: 'jee', name: 'JEE', blurb: 'Physics, Chemistry, Maths prep', color: '#1f4d3a' },
  { id: 'neet', name: 'NEET', blurb: 'Biology, NCERT & MCQ banks', color: '#b4462f' },
  { id: 'upsc', name: 'UPSC', blurb: 'Polity, History, CSAT', color: '#2d4a7a' },
  { id: 'cat', name: 'CAT', blurb: 'Quant, VARC, LRDI', color: '#7a3d6b' },
  { id: 'college', name: 'College Textbooks', blurb: 'Engineering, medicine, commerce', color: '#8a6a1f' },
  { id: 'other', name: 'Other Exams', blurb: 'GATE, CLAT, SSC, banking', color: '#3f5f5a' },
]

export interface Listing {
  id: string
  title: string
  author: string
  isbn?: string
  edition: string
  publicationYear: number
  category: CategoryId
  originalPrice: number
  /** AI-recommended price the seller accepted. Sellers never type this. */
  price: number
  priceRange: [number, number]
  confidence: Confidence
  /** "market" = backed by comparable listings; "estimated" = fallback assessment */
  evidence: 'market' | 'estimated'
  comparableCount: number
  pricingFactors: Array<string>
  condition: Condition
  wear: string
  city: string
  exchange: Exchange
  sellerName: string
  listedAt: string
  status: ListingStatus
  description: string
  featured?: boolean
}

export const listings: Array<Listing> = [
  {
    id: 'hc-verma-vol1',
    title: 'Concepts of Physics Vol. 1',
    author: 'H.C. Verma',
    isbn: '9788177091878',
    edition: '2022 Reprint',
    publicationYear: 2022,
    category: 'jee',
    originalPrice: 615,
    price: 330,
    priceRange: [300, 365],
    confidence: 'High',
    evidence: 'market',
    comparableCount: 6,
    pricingFactors: ['6 comparable listings for this edition', 'Light pencil marks in early chapters', 'Evergreen title — edition rarely changes'],
    condition: 'Good',
    wear: 'Pencil notes in chapters 1–4, spine intact',
    city: 'Kota',
    exchange: 'Shipping or in-person',
    sellerName: 'Aarav S.',
    listedAt: '2026-10-08T10:20:00Z',
    status: 'Active',
    description: 'Used for one year of JEE prep. All pages present, no torn sheets. Solved examples highlighted in yellow.',
    featured: true,
  },
  {
    id: 'ncert-bio-11-12',
    title: 'NCERT Biology Class 11 & 12 (Set)',
    author: 'NCERT',
    edition: '2024–25 Rationalised',
    publicationYear: 2024,
    category: 'neet',
    originalPrice: 520,
    price: 290,
    priceRange: [260, 320],
    confidence: 'High',
    evidence: 'market',
    comparableCount: 9,
    pricingFactors: ['Current rationalised syllabus edition', '9 comparable listings', 'Like-new condition'],
    condition: 'Like New',
    wear: 'No markings, minor cover crease',
    city: 'Hyderabad',
    exchange: 'Shipping',
    sellerName: 'Diya R.',
    listedAt: '2026-10-09T08:05:00Z',
    status: 'Active',
    description: 'Bought a second set by mistake — this one is practically unused.',
    featured: true,
  },
  {
    id: 'laxmikanth-polity',
    title: 'Indian Polity',
    author: 'M. Laxmikanth',
    isbn: '9789355322412',
    edition: '7th Edition',
    publicationYear: 2023,
    category: 'upsc',
    originalPrice: 1050,
    price: 560,
    priceRange: [510, 610],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 3,
    pricingFactors: ['Latest edition', 'Moderate highlighting', 'Only 3 comparable listings'],
    condition: 'Good',
    wear: 'Highlighting throughout, binding firm',
    city: 'Delhi',
    exchange: 'In-person',
    sellerName: 'Kabir M.',
    listedAt: '2026-10-07T14:40:00Z',
    status: 'Active',
    description: 'Cleared prelims with this. Margins have short notes linking articles to current affairs.',
    featured: true,
  },
  {
    id: 'arun-sharma-quant',
    title: 'How to Prepare for Quantitative Aptitude for CAT',
    author: 'Arun Sharma',
    isbn: '9789355326137',
    edition: '11th Edition',
    publicationYear: 2024,
    category: 'cat',
    originalPrice: 899,
    price: 470,
    priceRange: [420, 520],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 4,
    pricingFactors: ['Recent edition', 'Some solved exercises in pen', '4 comparable listings'],
    condition: 'Good',
    wear: 'Pen workings in Block II exercises',
    city: 'Pune',
    exchange: 'Shipping or in-person',
    sellerName: 'Meera T.',
    listedAt: '2026-10-06T09:10:00Z',
    status: 'Active',
    description: 'Clean apart from exercises I attempted. Includes previous-year paper section.',
  },
  {
    id: 'cengage-maths-algebra',
    title: 'Cengage Mathematics: Algebra',
    author: 'G. Tewani',
    edition: '2023 Edition',
    publicationYear: 2023,
    category: 'jee',
    originalPrice: 950,
    price: 420,
    priceRange: [380, 470],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 2,
    pricingFactors: ['Recent edition', 'Acceptable condition with worn cover', 'Few comparable listings'],
    condition: 'Acceptable',
    wear: 'Cover worn, a few dog-eared pages',
    city: 'Kota',
    exchange: 'In-person',
    sellerName: 'Ishaan P.',
    listedAt: '2026-10-05T16:30:00Z',
    status: 'Active',
    description: 'Solid book, just well-loved. Happy to meet near Talwandi.',
  },
  {
    id: 'ms-chouhan-organic',
    title: 'Advanced Problems in Organic Chemistry',
    author: 'M.S. Chouhan',
    edition: '2024 Edition',
    publicationYear: 2024,
    category: 'jee',
    originalPrice: 780,
    price: 455,
    priceRange: [420, 490],
    confidence: 'Low',
    evidence: 'estimated',
    comparableCount: 0,
    pricingFactors: ['No comparable listings yet — estimated price', 'Like-new condition', 'Recent edition'],
    condition: 'Like New',
    wear: 'Unused',
    city: 'Bengaluru',
    exchange: 'Shipping',
    sellerName: 'Ananya K.',
    listedAt: '2026-10-09T18:15:00Z',
    status: 'Active',
    description: 'Switched coaching material halfway, so this was never used.',
    featured: true,
  },
  {
    id: 'mtg-neet-champion',
    title: 'Objective NCERT at your Fingertips — Biology',
    author: 'MTG Editorial Board',
    edition: '2024 Edition',
    publicationYear: 2024,
    category: 'neet',
    originalPrice: 1125,
    price: 520,
    priceRange: [470, 570],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 3,
    pricingFactors: ['Answers marked in pencil', 'Current edition', '3 comparable listings'],
    condition: 'Good',
    wear: 'Pencil ticks on MCQs, easily erasable',
    city: 'Chennai',
    exchange: 'Shipping or in-person',
    sellerName: 'Rohan V.',
    listedAt: '2026-10-04T11:00:00Z',
    status: 'Active',
    description: 'Great MCQ bank. Pencil ticks only, no pen.',
  },
  {
    id: 'spectrum-modern-history',
    title: 'A Brief History of Modern India',
    author: 'Rajiv Ahir (Spectrum)',
    edition: '2023 Edition',
    publicationYear: 2023,
    category: 'upsc',
    originalPrice: 595,
    price: 300,
    priceRange: [270, 330],
    confidence: 'High',
    evidence: 'market',
    comparableCount: 7,
    pricingFactors: ['7 comparable listings', 'Good condition', 'Edition one year old'],
    condition: 'Good',
    wear: 'Light underlining',
    city: 'Delhi',
    exchange: 'Shipping',
    sellerName: 'Sana Q.',
    listedAt: '2026-10-03T07:45:00Z',
    status: 'Active',
    description: 'Standard Spectrum, good for prelims and mains revision.',
  },
  {
    id: 'rs-aggarwal-arith',
    title: 'Word Power Made Easy',
    author: 'Norman Lewis',
    isbn: '9789386538178',
    edition: 'Revised Edition',
    publicationYear: 2021,
    category: 'cat',
    originalPrice: 299,
    price: 140,
    priceRange: [120, 160],
    confidence: 'High',
    evidence: 'market',
    comparableCount: 11,
    pricingFactors: ['Very common title — 11 comparables', 'Older print', 'Good condition'],
    condition: 'Good',
    wear: 'Exercises filled in pencil',
    city: 'Mumbai',
    exchange: 'Shipping or in-person',
    sellerName: 'Neha J.',
    listedAt: '2026-10-02T13:20:00Z',
    status: 'Active',
    description: 'VARC essential. Pencil answers in exercises.',
  },
  {
    id: 'bs-grewal-engg-maths',
    title: 'Higher Engineering Mathematics',
    author: 'B.S. Grewal',
    isbn: '9788193328491',
    edition: '44th Edition',
    publicationYear: 2020,
    category: 'college',
    originalPrice: 985,
    price: 380,
    priceRange: [340, 420],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 4,
    pricingFactors: ['Edition is 6 years old', 'Newer edition available', 'Good condition'],
    condition: 'Good',
    wear: 'Name written on first page, otherwise clean',
    city: 'Hyderabad',
    exchange: 'In-person',
    sellerName: 'Vikram N.',
    listedAt: '2026-10-01T10:00:00Z',
    status: 'Active',
    description: 'First and second year engineering maths. Covers M1–M3.',
  },
  {
    id: 'guyton-physiology',
    title: 'Guyton and Hall Textbook of Medical Physiology',
    author: 'John E. Hall',
    isbn: '9788131264942',
    edition: '3rd South Asia Edition',
    publicationYear: 2021,
    category: 'college',
    originalPrice: 2000,
    price: 800,
    priceRange: [720, 880],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 3,
    pricingFactors: ['Heavy textbook, high original price', 'Some highlighting', '3 comparable listings'],
    condition: 'Good',
    wear: 'Highlighting in CVS and renal chapters',
    city: 'Bengaluru',
    exchange: 'Shipping or in-person',
    sellerName: 'Priya D.',
    listedAt: '2026-09-30T15:30:00Z',
    status: 'Active',
    description: 'MBBS first year. Binding solid, no loose pages.',
    featured: true,
  },
  {
    id: 'made-easy-gate-cse',
    title: 'GATE Computer Science — Previous Years Solved Papers',
    author: 'MADE EASY Editorial',
    edition: '2025 Edition',
    publicationYear: 2025,
    category: 'other',
    originalPrice: 650,
    price: 360,
    priceRange: [330, 395],
    confidence: 'Low',
    evidence: 'estimated',
    comparableCount: 1,
    pricingFactors: ['Only 1 comparable listing — estimated', 'Latest edition', 'Like-new condition'],
    condition: 'Like New',
    wear: 'Unused',
    city: 'Pune',
    exchange: 'Shipping',
    sellerName: 'Arjun B.',
    listedAt: '2026-10-09T12:00:00Z',
    status: 'Active',
    description: 'Bought extra copy for a friend who did not need it.',
  },
  {
    id: 'pradeep-chem-12',
    title: "Pradeep's New Course Chemistry Class 12",
    author: 'S.C. Kheterpal',
    edition: '2023 Edition',
    publicationYear: 2023,
    category: 'jee',
    originalPrice: 1495,
    price: 640,
    priceRange: [580, 700],
    confidence: 'Medium',
    evidence: 'market',
    comparableCount: 3,
    pricingFactors: ['Two-volume set', 'Acceptable condition', '3 comparable listings'],
    condition: 'Acceptable',
    wear: 'Spine cracked on Vol. 2, all pages present',
    city: 'Lucknow',
    exchange: 'Shipping or in-person',
    sellerName: 'Tanvi G.',
    listedAt: '2026-09-28T09:00:00Z',
    status: 'Reserved',
    description: 'Both volumes. Reserved for a buyer, may become available again.',
  },
]

export function getCategory(id: CategoryId) {
  return categories.find((c) => c.id === id)!
}

export function getListing(id: string) {
  return listings.find((l) => l.id === id)
}

/** Sample buyer requests shown on the dashboard preview. */
export interface SampleRequest {
  id: string
  title: string
  edition: string
  tier: 'Free' | 'Premium'
  status:
    | 'Draft'
    | 'Awaiting Payment'
    | 'Payment Failed'
    | 'Searching'
    | 'Seller Responses Received'
    | 'Offer Selected'
    | 'Completed'
    | 'No Match'
    | 'Cancelled'
    | 'Refund Pending'
    | 'Refunded'
  budget: number
  deadline: string
  offers: number
  paymentStatus: 'Not required' | 'Verified (test)' | 'Pending' | 'Failed'
}

export const sampleRequests: Array<SampleRequest> = [
  {
    id: 'req-1042',
    title: 'Problems in Physics — I.E. Irodov',
    edition: 'Any recent reprint',
    tier: 'Premium',
    status: 'Seller Responses Received',
    budget: 350,
    deadline: '2026-10-15',
    offers: 2,
    paymentStatus: 'Verified (test)',
  },
  {
    id: 'req-1038',
    title: 'Indian Economy — Ramesh Singh',
    edition: '16th Edition',
    tier: 'Free',
    status: 'Searching',
    budget: 500,
    deadline: '2026-10-21',
    offers: 0,
    paymentStatus: 'Not required',
  },
]

export interface SampleOffer {
  id: string
  requestId: string
  sellerName: string
  condition: Condition
  edition: string
  price: number
  confidence: Confidence
  city: string
  exchange: Exchange
  note: string
}

export const sampleOffers: Array<SampleOffer> = [
  {
    id: 'off-1',
    requestId: 'req-1042',
    sellerName: 'Harsh L.',
    condition: 'Good',
    edition: '2021 Arihant reprint',
    price: 240,
    confidence: 'High',
    city: 'Kota',
    exchange: 'Shipping or in-person',
    note: 'Solutions written for first 2 chapters.',
  },
  {
    id: 'off-2',
    requestId: 'req-1042',
    sellerName: 'Simran A.',
    condition: 'Like New',
    edition: '2023 GK Publications',
    price: 310,
    confidence: 'Medium',
    city: 'Jaipur',
    exchange: 'Shipping',
    note: 'Unused, original receipt available.',
  },
]

/** Configurable business settings — will live in an admin-managed settings table. */
export const finderSettings = {
  premiumFee: 29,
  matchingDays: 7,
}
