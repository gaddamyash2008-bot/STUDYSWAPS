import { useEffect, useRef, useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { Sparkles, ArrowLeft, ArrowRight, ImagePlus, X, Check, RefreshCw, Info, AlertTriangle, PartyPopper } from 'lucide-react'
import { categories, type CategoryId, type Condition, type Exchange } from '@/data/fixtures'
import { calculateSavings, inr, previewPrice, type PricingPreview } from '@/lib/pricing'
import { ConfidenceBadge } from '@/components/Badges'
import { BookCover } from '@/components/BookCover'

export const Route = createFileRoute('/sell')({
  head: () => ({ meta: [{ title: 'Sell a book · StudySwap' }] }),
  component: Sell,
})

interface Details {
  title: string
  author: string
  isbn: string
  edition: string
  publicationYear: string
  category: CategoryId | ''
  originalPrice: string
  condition: Condition | ''
  wear: string
  description: string
  city: string
  exchange: Exchange
}

const empty: Details = {
  title: '', author: '', isbn: '', edition: '', publicationYear: '', category: '',
  originalPrice: '', condition: '', wear: '', description: '', city: '', exchange: 'Shipping or in-person',
}

/** Changing any of these after an assessment requires a fresh assessment. */
const pricingKeys: Array<keyof Details> = ['title', 'author', 'isbn', 'edition', 'publicationYear', 'originalPrice', 'condition', 'wear']

const MAX_IMG = 5 * 1024 * 1024
const OK_TYPES = ['image/jpeg', 'image/png', 'image/webp']

function validate(d: Details) {
  const e: Partial<Record<keyof Details | 'photos', string>> = {}
  const year = new Date().getFullYear()
  if (d.title.trim().length < 2) e.title = 'Enter the book title.'
  if (d.author.trim().length < 2) e.author = 'Enter the author or publisher.'
  if (d.isbn && !/^(97[89])?\d{9}[\dX]$/i.test(d.isbn.replace(/[-\s]/g, ''))) e.isbn = 'ISBN should be 10 or 13 digits.'
  if (!d.edition.trim()) e.edition = 'Enter the edition, e.g. "7th" or "2024".'
  const y = Number(d.publicationYear)
  if (!Number.isInteger(y) || y < 1950 || y > year) e.publicationYear = `Enter a year between 1950 and ${year}.`
  if (!d.category) e.category = 'Choose a category.'
  const p = Number(d.originalPrice)
  if (!(p > 0) || p > 50000) e.originalPrice = 'Original price must be between ₹1 and ₹50,000.'
  if (!d.condition) e.condition = 'Choose the current condition.'
  if (!d.city.trim()) e.city = 'Enter your city or general area.'
  return e
}

function Sell() {
  const [step, setStep] = useState<1 | 2 | 3>(1)
  const [d, setD] = useState<Details>(empty)
  const [photos, setPhotos] = useState<Array<{ name: string; url: string }>>([])
  const [photoError, setPhotoError] = useState('')
  const [errors, setErrors] = useState<ReturnType<typeof validate>>({})
  const [assessment, setAssessment] = useState<PricingPreview | null>(null)
  const [assessedFor, setAssessedFor] = useState('')
  const [history, setHistory] = useState<Array<{ at: Date; price: number }>>([])
  const [loading, setLoading] = useState(false)
  const [agreed, setAgreed] = useState(false)
  const [publishing, setPublishing] = useState(false)
  const topRef = useRef<HTMLDivElement>(null)

  const pricingSig = pricingKeys.map((k) => d[k]).join('|')
  const stale = assessment !== null && assessedFor !== pricingSig

  useEffect(() => topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), [step])

  const upd = (k: keyof Details) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setD({ ...d, [k]: e.target.value })

  const addPhotos = (files: FileList | null) => {
    if (!files) return
    setPhotoError('')
    const next = [...photos]
    for (const f of Array.from(files)) {
      if (!OK_TYPES.includes(f.type)) { setPhotoError('Only JPG, PNG or WebP images.'); continue }
      if (f.size > MAX_IMG) { setPhotoError('Each photo must be under 5 MB.'); continue }
      if (next.length >= 5) { setPhotoError('Up to 5 photos.'); break }
      next.push({ name: f.name, url: URL.createObjectURL(f) })
    }
    setPhotos(next)
  }

  const runAssessment = () => {
    const e = validate(d)
    setErrors(e)
    if (Object.keys(e).length) return
    setStep(2)
    setLoading(true)
    setAgreed(false)
    setTimeout(() => {
      const r = previewPrice({
        title: d.title, author: d.author, isbn: d.isbn || undefined, edition: d.edition,
        publicationYear: Number(d.publicationYear), originalPrice: Number(d.originalPrice),
        condition: d.condition as Condition, wear: d.wear,
      })
      setAssessment(r)
      setAssessedFor(pricingSig)
      setHistory((h) => [{ at: new Date(), price: r.recommended }, ...h])
      setLoading(false)
    }, 1400)
  }

  const publish = () => {
    if (!agreed || stale || publishing) return
    setPublishing(true)
    setTimeout(() => { setPublishing(false); setStep(3) }, 900)
  }

  return (
    <div ref={topRef} className="mx-auto max-w-5xl scroll-mt-20 px-5 py-10">
      <p className="eyebrow">Sell a book</p>
      <h1 className="mt-2 text-3xl md:text-4xl">List your book in three steps</h1>
      <Stepper step={step} />

      {step === 1 && (
        <form className="mt-8 grid gap-8 lg:grid-cols-[1fr_280px]" noValidate onSubmit={(e) => { e.preventDefault(); runAssessment() }}>
          <div className="card space-y-6 p-6 md:p-8">
            <fieldset className="grid gap-4 sm:grid-cols-2">
              <legend className="mb-3 font-display text-xl">About the book</legend>
              <F label="Book title *" err={errors.title} className="sm:col-span-2"><input className="field" value={d.title} onChange={upd('title')} placeholder="e.g. Concepts of Physics Vol. 1" /></F>
              <F label="Author / publisher *" err={errors.author}><input className="field" value={d.author} onChange={upd('author')} /></F>
              <F label="ISBN (if available)" err={errors.isbn}><input className="field" value={d.isbn} onChange={upd('isbn')} inputMode="numeric" placeholder="978…" /></F>
              <F label="Edition *" err={errors.edition}><input className="field" value={d.edition} onChange={upd('edition')} placeholder="e.g. 7th Edition" /></F>
              <F label="Publication year *" err={errors.publicationYear}><input className="field" type="number" value={d.publicationYear} onChange={upd('publicationYear')} placeholder="2023" /></F>
              <F label="Exam / academic category *" err={errors.category}>
                <select className="field" value={d.category} onChange={upd('category')}>
                  <option value="">Choose…</option>
                  {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </F>
              <F label="Original purchase price (₹) *" err={errors.originalPrice}><input className="field" type="number" min={1} value={d.originalPrice} onChange={upd('originalPrice')} placeholder="MRP you paid" /></F>
            </fieldset>

            <fieldset>
              <legend className="mb-3 font-display text-xl">Condition *</legend>
              <div className="grid gap-3 sm:grid-cols-3">
                {([['Like New', 'No markings, crisp pages'], ['Good', 'Light notes or highlights'], ['Acceptable', 'Heavy use, all pages present']] as const).map(([c, hint]) => (
                  <label key={c} className={`cursor-pointer rounded-xl border-2 p-4 transition ${d.condition === c ? 'border-forest bg-forest-soft' : 'border-line hover:border-forest/40'}`}>
                    <input type="radio" name="condition" value={c} checked={d.condition === c} onChange={upd('condition')} className="sr-only" />
                    <span className="font-semibold">{c}</span>
                    <span className="mt-1 block text-xs text-ink-soft">{hint}</span>
                  </label>
                ))}
              </div>
              {errors.condition && <p className="field-error">{errors.condition}</p>}
              <F label="Wear or damage" className="mt-4"><input className="field" value={d.wear} onChange={upd('wear')} placeholder="e.g. Pencil notes in chapter 2, spine creased" /></F>
            </fieldset>

            <fieldset>
              <legend className="mb-3 font-display text-xl">Photos</legend>
              <div className="flex flex-wrap gap-3">
                {photos.map((p, i) => (
                  <div key={p.url} className="relative h-24 w-20 overflow-hidden rounded-lg border border-line">
                    <img src={p.url} alt={p.name} className="h-full w-full object-cover" />
                    <button type="button" aria-label={`Remove ${p.name}`} onClick={() => setPhotos(photos.filter((_, j) => j !== i))} className="absolute right-1 top-1 rounded-full bg-ink/70 p-0.5 text-white"><X size={12} /></button>
                  </div>
                ))}
                {photos.length < 5 && (
                  <label className="grid h-24 w-20 cursor-pointer place-items-center rounded-lg border-2 border-dashed border-line text-ink-soft hover:border-forest hover:text-forest">
                    <ImagePlus size={22} />
                    <input type="file" accept={OK_TYPES.join(',')} multiple className="sr-only" onChange={(e) => addPhotos(e.target.files)} />
                  </label>
                )}
              </div>
              <p className="mt-2 text-xs text-ink-soft">Cover plus condition shots. JPG, PNG or WebP, up to 5 MB each.</p>
              {photoError && <p className="field-error">{photoError}</p>}
            </fieldset>

            <fieldset className="grid gap-4 sm:grid-cols-2">
              <legend className="mb-3 font-display text-xl">Handover</legend>
              <F label="City or general area *" err={errors.city}><input className="field" value={d.city} onChange={upd('city')} placeholder="e.g. Kota" /></F>
              <F label="Exchange preference">
                <select className="field" value={d.exchange} onChange={upd('exchange')}>
                  <option>Shipping or in-person</option><option>Shipping</option><option>In-person</option>
                </select>
              </F>
              <F label="Description (optional)" className="sm:col-span-2"><textarea className="field min-h-24" value={d.description} onChange={upd('description')} maxLength={600} /></F>
            </fieldset>
          </div>

          <aside className="space-y-4">
            <div className="card sticky top-24 p-5">
              <p className="flex items-center gap-2 text-sm font-bold text-forest"><Sparkles size={16} /> Where's the price field?</p>
              <p className="mt-2 text-sm text-ink-soft">
                There isn't one. StudySwap recommends a fair price from comparable listings, edition and condition.
                You review it and choose whether to publish.
              </p>
              <button type="submit" className="btn-primary mt-5 w-full">Get my AI price <ArrowRight size={16} /></button>
              {Object.keys(errors).length > 0 && <p className="field-error mt-3" role="alert">Please fix the highlighted fields.</p>}
            </div>
          </aside>
        </form>
      )}

      {step === 2 && (
        <div className="mt-8 grid gap-8 lg:grid-cols-[220px_1fr]">
          <div className="mx-auto w-full max-w-[220px]">
            {photos[0] ? <img src={photos[0].url} alt="Book cover" className="aspect-[3/4] w-full rounded-lg object-cover" /> :
              <BookCover title={d.title} author={d.author} category={(d.category || 'other') as CategoryId} />}
            <p className="mt-3 text-sm font-semibold">{d.title}</p>
            <p className="text-xs text-ink-soft">{d.author} · {d.edition} · {d.condition}</p>
          </div>

          <div className="card p-6 md:p-8" aria-live="polite">
            {loading || !assessment ? (
              <div className="py-12 text-center">
                <RefreshCw className="mx-auto animate-spin text-forest" size={32} />
                <p className="mt-4 font-semibold">Assessing your book…</p>
                <p className="mt-1 text-sm text-ink-soft">Checking comparable listings for this title and edition</p>
              </div>
            ) : (
              <PriceReview
                a={assessment} original={Number(d.originalPrice)} stale={stale}
                agreed={agreed} setAgreed={setAgreed} history={history} publishing={publishing}
                onPublish={publish} onEdit={() => setStep(1)} onReassess={runAssessment}
              />
            )}
          </div>
        </div>
      )}

      {step === 3 && assessment && (
        <div className="card mx-auto mt-8 max-w-xl p-10 text-center">
          <PartyPopper className="mx-auto text-marigold" size={40} />
          <h2 className="mt-4 text-3xl">Listing ready at {inr(assessment.recommended)}</h2>
          <p className="mt-3 text-ink-soft">
            This preview doesn't save listings yet — publishing goes live once seller accounts launch.
            Your flow, price and consent step work exactly as they will.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <button type="button" className="btn-primary" onClick={() => { setD(empty); setPhotos([]); setAssessment(null); setHistory([]); setStep(1) }}>List another book</button>
            <Link to="/books" className="btn-ghost">Browse books</Link>
          </div>
        </div>
      )}
    </div>
  )
}

function PriceReview(p: {
  a: PricingPreview; original: number; stale: boolean; agreed: boolean; setAgreed: (b: boolean) => void
  history: Array<{ at: Date; price: number }>; publishing: boolean
  onPublish: () => void; onEdit: () => void; onReassess: () => void
}) {
  const s = calculateSavings(p.original, p.a.recommended)!
  return (
    <div>
      <div className="flex flex-wrap items-start justify-between gap-3">
        <p className="eyebrow">Recommended price</p>
        <ConfidenceBadge confidence={p.a.confidence} evidence={p.a.evidence} />
      </div>
      <p className="mt-2 font-display text-6xl font-semibold">{inr(p.a.recommended)}</p>
      <p className="mt-1 text-sm text-ink-soft">Estimated range {inr(p.a.range[0])} – {inr(p.a.range[1])}</p>

      <div className="mt-6 grid grid-cols-3 gap-3 rounded-xl bg-forest-soft p-4 text-forest">
        <Stat k="Original price" v={inr(p.original)} />
        <Stat k="Buyer saves (est.)" v={inr(s.savings)} />
        <Stat k="Discount" v={`${s.discountPct.toFixed(0)}%`} />
      </div>

      {p.a.evidence === 'estimated' && (
        <p className="mt-4 flex gap-2 rounded-xl bg-brick-soft p-3 text-sm text-brick">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" />
          No comparable listings were found, so this is an estimated price rather than a market-verified one.
        </p>
      )}

      <div className="mt-6">
        <p className="text-sm font-semibold">Main factors</p>
        <ul className="mt-2 space-y-1.5 text-sm text-ink-soft">
          {p.a.factors.map((f) => <li key={f} className="flex gap-2"><Check size={15} className="mt-0.5 shrink-0 text-forest" />{f}</li>)}
        </ul>
        <p className="mt-3 flex gap-1.5 text-xs text-ink-soft"><Info size={13} className="mt-0.5 shrink-0" /> Preview engine: rule-based estimate from sample listings. The live AI assessment replaces this in a later release.</p>
      </div>

      {p.stale && (
        <p className="mt-6 rounded-xl bg-marigold-soft p-3 text-sm font-semibold text-[#6b470d]" role="alert">
          You changed details that affect pricing. Request a new assessment before publishing.
        </p>
      )}

      <label className="mt-6 flex cursor-pointer gap-3 rounded-xl border border-line p-4">
        <input type="checkbox" className="mt-1 h-4 w-4 accent-forest" checked={p.agreed} disabled={p.stale} onChange={(e) => p.setAgreed(e.target.checked)} />
        <span className="text-sm">I agree to publish this listing at <b>{inr(p.a.recommended)}</b>, and confirm the details and photos honestly describe my book.</span>
      </label>

      <div className="mt-6 flex flex-wrap gap-3">
        <button type="button" className="btn-primary" disabled={!p.agreed || p.stale || p.publishing} onClick={p.onPublish}>
          {p.publishing ? <RefreshCw size={16} className="animate-spin" /> : <Check size={16} />} Accept & publish
        </button>
        <button type="button" className="btn-ghost" onClick={p.onEdit}><ArrowLeft size={16} /> Correct details</button>
        <button type="button" className="btn-ghost" onClick={p.onReassess}><RefreshCw size={16} /> Request reassessment</button>
      </div>

      {p.history.length > 1 && (
        <div className="mt-6 border-t border-line pt-4">
          <p className="text-xs font-bold uppercase tracking-wide text-ink-soft">Pricing history</p>
          <ul className="mt-2 space-y-1 text-sm">
            {p.history.map((h, i) => (
              <li key={i} className="flex justify-between text-ink-soft">
                <span>{h.at.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}{i === 0 && ' · current'}</span>
                <span className="font-semibold text-ink">{inr(h.price)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <p className="text-xs font-semibold opacity-80">{k}</p>
      <p className="font-display text-xl font-semibold">{v}</p>
    </div>
  )
}

function Stepper({ step }: { step: number }) {
  const steps = ['Book details', 'AI price review', 'Published']
  return (
    <ol className="mt-6 flex flex-wrap items-center gap-2 text-sm">
      {steps.map((s, i) => (
        <li key={s} className="flex items-center gap-2">
          <span className={`grid h-7 w-7 place-items-center rounded-full text-xs font-bold ${step > i + 1 ? 'bg-forest text-white' : step === i + 1 ? 'bg-marigold text-ink' : 'bg-paper-deep text-ink-soft'}`}>
            {step > i + 1 ? <Check size={14} /> : i + 1}
          </span>
          <span className={step === i + 1 ? 'font-semibold' : 'text-ink-soft'}>{s}</span>
          {i < steps.length - 1 && <span className="mx-1 h-px w-8 bg-line" />}
        </li>
      ))}
    </ol>
  )
}

function F({ label, err, className = '', children }: { label: string; err?: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={className}>
      <label className="field-label">{label}
        <span className="mt-1.5 block font-normal">{children}</span>
      </label>
      {err && <p className="field-error">{err}</p>}
    </div>
  )
}
