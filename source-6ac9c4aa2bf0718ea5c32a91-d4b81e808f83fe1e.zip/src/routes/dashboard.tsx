import { useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { Crown, Bell, BookOpen, Inbox, Check, X, MapPin, CalendarClock } from 'lucide-react'
import { listings, sampleOffers, sampleRequests, type SampleOffer } from '@/data/fixtures'
import { inr } from '@/lib/pricing'
import { ConditionBadge, ConfidenceBadge, SampleTag } from '@/components/Badges'

export const Route = createFileRoute('/dashboard')({
  head: () => ({ meta: [{ title: 'My dashboard · StudySwap' }] }),
  component: Dashboard,
})

const notifications = [
  { t: 'New offer from Simran A. on "Problems in Physics"', when: '2h ago' },
  { t: 'Premium payment verified (test mode) — priority matching started', when: '1d ago' },
  { t: '2 sellers notified about your Irodov request', when: '1d ago' },
]

function Dashboard() {
  const [tab, setTab] = useState<'buyer' | 'seller'>('buyer')
  const myListings = listings.filter((l) => ['Aarav S.', 'Tanvi G.'].includes(l.sellerName))
  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3"><h1 className="text-3xl md:text-4xl">My dashboard</h1><SampleTag /></div>
          <p className="mt-1 text-sm text-ink-soft">A preview of your requests, offers and listings. <Link to="/login" className="font-semibold text-forest underline">Log in</Link> to see your own.</p>
        </div>
        <div className="flex rounded-full border border-line bg-card p-1" role="tablist">
          {(['buyer', 'seller'] as const).map((t) => (
            <button key={t} role="tab" aria-selected={tab === t} type="button" onClick={() => setTab(t)}
              className={`rounded-full px-4 py-1.5 text-sm font-semibold capitalize ${tab === t ? 'bg-forest text-white' : 'text-ink-soft'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_300px]">
        <div className="space-y-8">{tab === 'buyer' ? <Buyer /> : <Seller mine={myListings} />}</div>
        <aside className="card h-fit p-5">
          <p className="flex items-center gap-2 font-semibold"><Bell size={16} /> Notifications</p>
          <ul className="mt-4 space-y-3">
            {notifications.map((n) => (
              <li key={n.t} className="border-l-2 border-marigold pl-3 text-sm">
                <p>{n.t}</p><p className="text-xs text-ink-soft">{n.when}</p>
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </div>
  )
}

function Buyer() {
  const [selected, setSelected] = useState<string | null>(null)
  const [declined, setDeclined] = useState<Array<string>>([])
  const offers = sampleOffers.filter((o) => !declined.includes(o.id))
  return (
    <>
      <section>
        <h2 className="text-xl">My book requests</h2>
        <div className="mt-4 space-y-3">
          {sampleRequests.map((r) => (
            <div key={r.id} className="card flex flex-wrap items-center gap-4 p-5">
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 font-semibold">
                  {r.tier === 'Premium' && <Crown size={15} className="text-marigold" />}{r.title}
                </p>
                <p className="text-xs text-ink-soft">{r.edition} · budget {inr(r.budget)} · payment: {r.paymentStatus}</p>
              </div>
              <span className={`chip ${r.tier === 'Premium' ? 'bg-marigold-soft text-[#8a5a10]' : 'bg-paper-deep text-ink-soft'}`}>{r.tier}</span>
              <span className="chip bg-forest-soft text-forest">{selected && r.id === 'req-1042' ? 'Offer Selected' : r.status}</span>
              <span className="flex items-center gap-1 text-xs text-ink-soft"><CalendarClock size={13} /> until {new Date(r.deadline).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
            </div>
          ))}
        </div>
        <Link to="/find" className="btn-ghost mt-4">New request</Link>
      </section>

      <section>
        <h2 className="text-xl">Compare offers · Problems in Physics</h2>
        <p className="mt-1 text-sm text-ink-soft">Selecting an offer doesn't complete a purchase — you and the seller arrange the exchange.</p>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {offers.map((o) => <OfferCard key={o.id} o={o} selected={selected === o.id} disabled={!!selected && selected !== o.id}
            onSelect={() => setSelected(selected === o.id ? null : o.id)} onDecline={() => setDeclined([...declined, o.id])} />)}
          {offers.length === 0 && <p className="card p-6 text-sm text-ink-soft">No open offers. We'll notify you when sellers respond.</p>}
        </div>
      </section>
    </>
  )
}

function OfferCard({ o, selected, disabled, onSelect, onDecline }: { o: SampleOffer; selected: boolean; disabled: boolean; onSelect: () => void; onDecline: () => void }) {
  return (
    <div className={`card p-5 ${selected ? 'border-2 border-forest' : ''} ${disabled ? 'opacity-60' : ''}`}>
      <div className="flex items-start justify-between">
        <div><p className="font-semibold">{o.sellerName}</p><p className="flex items-center gap-1 text-xs text-ink-soft"><MapPin size={11} />{o.city} · {o.exchange}</p></div>
        <p className="font-display text-2xl font-semibold">{inr(o.price)}</p>
      </div>
      <div className="mt-3 flex flex-wrap gap-1.5"><ConditionBadge condition={o.condition} /><ConfidenceBadge confidence={o.confidence} evidence="market" /></div>
      <p className="mt-3 text-sm"><span className="text-ink-soft">Edition:</span> {o.edition}</p>
      <p className="mt-1 text-sm text-ink-soft">“{o.note}”</p>
      <div className="mt-4 flex gap-2">
        <button type="button" className="btn-primary !py-2" disabled={disabled} onClick={onSelect}><Check size={15} />{selected ? 'Selected — undo' : 'Select offer'}</button>
        {!selected && <button type="button" className="btn-ghost !py-2" disabled={disabled} onClick={onDecline}><X size={15} />Decline</button>}
      </div>
      {selected && <p className="mt-3 rounded-lg bg-forest-soft p-2 text-xs text-forest">In-app chat with {o.sellerName} opens once accounts are live. Contact details are shared only if you both agree.</p>}
    </div>
  )
}

function Seller({ mine }: { mine: typeof listings }) {
  return (
    <>
      <section>
        <div className="flex items-center justify-between"><h2 className="text-xl">My listings</h2><Link to="/sell" className="btn-primary !py-2">List a book</Link></div>
        <div className="mt-4 space-y-3">
          {mine.map((l) => (
            <div key={l.id} className="card flex flex-wrap items-center gap-4 p-5">
              <BookOpen className="text-forest" size={20} />
              <div className="min-w-0 flex-1">
                <Link to="/books/$bookId" params={{ bookId: l.id }} className="font-semibold hover:text-forest">{l.title}</Link>
                <p className="text-xs text-ink-soft">AI price {inr(l.price)} · range {inr(l.priceRange[0])}–{inr(l.priceRange[1])}</p>
              </div>
              <ConfidenceBadge confidence={l.confidence} evidence={l.evidence} />
              <span className="chip bg-paper-deep text-ink">{l.status}</span>
            </div>
          ))}
        </div>
      </section>
      <section>
        <h2 className="text-xl">Book requests you could fill</h2>
        <div className="card mt-4 flex items-center gap-4 p-5">
          <Inbox className="text-marigold" size={20} />
          <div className="flex-1 text-sm">
            <p className="font-semibold">A buyer in Kota is looking for “Cengage Physics: Mechanics 1”</p>
            <p className="text-ink-soft">Premium request · budget {inr(450)} · Good or better</p>
          </div>
          <Link to="/sell" className="btn-ghost !py-2">Respond with a listing</Link>
        </div>
      </section>
    </>
  )
}
