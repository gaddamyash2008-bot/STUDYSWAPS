import { useState } from 'react'
import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import {
  Search,
  Sparkles,
  ScanSearch,
  Camera,
  BadgeIndianRupee,
  Handshake,
  ArrowRight,
  Check,
  Bell,
  Clock,
} from 'lucide-react'
import { categories, finderSettings, listings } from '@/data/fixtures'
import { BookCard } from '@/components/BookCard'
import { BookCover } from '@/components/BookCover'
import { SampleTag } from '@/components/Badges'
import { calculateSavings, inr } from '@/lib/pricing'

export const Route = createFileRoute('/')({ component: Home })

function Home() {
  const featured = listings.filter((l) => l.featured && l.status === 'Active').slice(0, 5)
  const recent = [...listings]
    .filter((l) => l.status === 'Active')
    .sort((a, b) => b.listedAt.localeCompare(a.listedAt))
    .slice(0, 5)

  return (
    <>
      <Hero />

      <section className="mx-auto max-w-7xl px-5 pt-16" aria-labelledby="cat-h">
        <h2 id="cat-h" className="text-2xl md:text-3xl">Shop by exam</h2>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {categories.map((c) => (
            <Link
              key={c.id}
              to="/books"
              search={{ category: c.id }}
              className="card group p-4 transition hover:border-forest/50"
            >
              <span className="block h-1.5 w-10 rounded-full" style={{ background: c.color }} />
              <p className="mt-3 font-display text-lg font-semibold group-hover:text-forest">{c.name}</p>
              <p className="mt-0.5 text-xs text-ink-soft">{c.blurb}</p>
              <p className="mt-3 text-xs font-semibold text-forest">
                {listings.filter((l) => l.category === c.id && l.status === 'Active').length} listed
              </p>
            </Link>
          ))}
        </div>
      </section>

      <Shelf title="Featured books" books={featured} />
      <Shelf title="Recently listed" books={recent} />

      <AIPricing />
      <FinderPromo />
      <SavingsCalculator />
      <HowItWorks />
    </>
  )
}

function Hero() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  return (
    <section className="relative overflow-hidden border-b border-line bg-paper-deep/60">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 py-14 md:py-20 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <p className="eyebrow">Student-to-student · India</p>
          <h1 className="mt-4 text-4xl font-semibold leading-[1.05] md:text-6xl">
            Last year's toppers'<br /> books, <em className="text-forest">this year's</em> prices.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-ink-soft">
            Buy and sell second-hand JEE, NEET, UPSC, CAT and college books. Every listing gets a fair,
            AI-recommended price — and if you can't find a book, our Premium Book Finder goes looking for you.
          </p>
          <form
            role="search"
            className="mt-8 flex max-w-xl items-center gap-2 rounded-full border border-line bg-white p-1.5 shadow-sm focus-within:ring-2 focus-within:ring-forest/25"
            onSubmit={(e) => {
              e.preventDefault()
              navigate({ to: '/books', search: q.trim() ? { q: q.trim() } : {} })
            }}
          >
            <Search className="ml-3 shrink-0 text-ink-soft" size={18} aria-hidden />
            <label htmlFor="hero-q" className="sr-only">Search books</label>
            <input
              id="hero-q"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Title, author, edition or exam — e.g. HC Verma"
              className="min-w-0 flex-1 bg-transparent py-2 text-sm outline-none"
            />
            <button className="btn-primary" type="submit">Search</button>
          </form>
          <div className="mt-4 flex flex-wrap gap-2 text-xs text-ink-soft">
            Popular:
            {['HC Verma', 'Laxmikanth', 'NCERT Biology', 'Arun Sharma'].map((t) => (
              <Link key={t} to="/books" search={{ q: t }} className="underline decoration-line underline-offset-4 hover:text-forest">
                {t}
              </Link>
            ))}
          </div>
        </div>

        <div className="relative mx-auto hidden h-[400px] w-full max-w-md sm:block" aria-hidden>
          <div className="absolute left-4 top-8 w-44 -rotate-6"><BookCover title="Concepts of Physics" author="H.C. Verma" category="jee" /></div>
          <div className="absolute left-36 top-0 z-10 w-48 rotate-3"><BookCover title="Indian Polity" author="M. Laxmikanth" category="upsc" /></div>
          <div className="absolute bottom-0 right-2 w-40 rotate-[8deg]"><BookCover title="NCERT Biology" author="NCERT" category="neet" /></div>
          <div className="absolute bottom-8 left-0 z-20 w-64 rounded-2xl border border-line bg-card p-4 shadow-xl">
            <p className="flex items-center gap-1.5 text-xs font-bold text-forest"><Sparkles size={14} /> AI-recommended price</p>
            <p className="mt-2 flex items-baseline gap-2">
              <span className="font-display text-3xl font-semibold">₹330</span>
              <span className="text-sm text-ink-soft line-through">₹615</span>
            </p>
            <p className="mt-1 text-xs text-ink-soft">Range ₹300–₹365 · 6 comparables · You save ₹285</p>
          </div>
        </div>
      </div>
    </section>
  )
}

function Shelf({ title, books }: { title: string; books: typeof listings }) {
  return (
    <section className="mx-auto max-w-7xl px-5 pt-16">
      <div className="flex items-end justify-between gap-4">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl md:text-3xl">{title}</h2>
          <SampleTag />
        </div>
        <Link to="/books" className="flex items-center gap-1 text-sm font-semibold text-forest hover:underline">
          View all <ArrowRight size={14} />
        </Link>
      </div>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {books.map((b) => <BookCard key={b.id} book={b} />)}
      </div>
    </section>
  )
}

function AIPricing() {
  const points = [
    { icon: Camera, t: 'Describe your book', d: 'Title, edition, original price, condition and photos. No price box — on purpose.' },
    { icon: ScanSearch, t: 'We gather real evidence', d: 'Comparable StudySwap listings for the same title and edition. Nothing invented.' },
    { icon: Sparkles, t: 'AI recommends a fair price', d: 'A price, a range, a confidence level and the reasons behind it — checked by server-side safeguards.' },
    { icon: Check, t: 'You approve and publish', d: 'Accept the price to go live, or correct details and request a reassessment.' },
  ]
  return (
    <section className="mx-auto mt-24 max-w-7xl px-5">
      <div className="grid gap-10 overflow-hidden rounded-3xl bg-forest p-8 text-paper md:p-12 lg:grid-cols-[1fr_1.2fr]">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-marigold">AI-powered pricing</p>
          <h2 className="mt-3 text-3xl md:text-4xl">No haggling. No guesswork. A fair price on every book.</h2>
          <p className="mt-4 text-paper/80">
            Sellers don't pick a price — StudySwap recommends one from real comparable listings and the book's
            age, edition and condition. When evidence is thin, we say so and label it an estimate.
          </p>
          <Link to="/sell" className="btn-accent mt-8">Try it: price my book <ArrowRight size={16} /></Link>
        </div>
        <ol className="grid gap-4 sm:grid-cols-2">
          {points.map((p, i) => (
            <li key={p.t} className="rounded-2xl bg-white/[0.06] p-5 ring-1 ring-white/10">
              <div className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-full bg-marigold text-ink"><p.icon size={18} /></span>
                <span className="text-xs font-bold text-paper/50">STEP {i + 1}</span>
              </div>
              <p className="mt-4 font-semibold text-paper">{p.t}</p>
              <p className="mt-1 text-sm text-paper/70">{p.d}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}

function FinderPromo() {
  return (
    <section className="mx-auto mt-16 max-w-7xl px-5">
      <div className="grid items-center gap-10 rounded-3xl border-2 border-marigold bg-marigold-soft p-8 md:p-12 lg:grid-cols-2">
        <div>
          <p className="eyebrow !text-[#8a5a10]">Premium Book Finder</p>
          <h2 className="mt-3 text-3xl md:text-4xl">Can't find that one edition? We'll go looking.</h2>
          <p className="mt-4 text-ink-soft">
            Post a request for free, or go Premium for {inr(finderSettings.premiumFee)} to jump the matching
            queue and reach more sellers for {finderSettings.matchingDays} days. The fee covers the matching
            service, not the book — and we never promise a book will be found.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/find" className="btn-primary">Request a book <ArrowRight size={16} /></Link>
            <Link to="/legal/$page" params={{ page: 'refunds' }} className="btn-ghost">Refund policy</Link>
          </div>
        </div>
        <ul className="grid gap-3 sm:grid-cols-2">
          {[
            { icon: Clock, t: 'Priority matching queue', d: 'Your request is matched before free requests.' },
            { icon: Bell, t: 'Wider seller alerts', d: 'We notify opted-in sellers with matching books.' },
            { icon: Handshake, t: 'Compare real offers', d: 'Side-by-side, each with its own AI price.' },
            { icon: BadgeIndianRupee, t: 'Know your budget fit', d: 'See instantly if an offer fits your max budget.' },
          ].map((b) => (
            <li key={b.t} className="rounded-2xl bg-card p-5 shadow-sm">
              <b.icon className="text-forest" size={20} />
              <p className="mt-3 font-semibold">{b.t}</p>
              <p className="mt-1 text-sm text-ink-soft">{b.d}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}

function SavingsCalculator() {
  const [original, setOriginal] = useState(2000)
  const [price, setPrice] = useState(800)
  const [budget, setBudget] = useState(1000)
  const s = calculateSavings(original, price)
  return (
    <section className="mx-auto mt-24 max-w-7xl px-5" aria-labelledby="calc-h">
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <p className="eyebrow">Savings calculator</p>
          <h2 id="calc-h" className="mt-3 text-3xl md:text-4xl">See how much reusing a book saves.</h2>
          <p className="mt-4 text-ink-soft">
            Savings = Original price − Selling price. Discount = Savings ÷ Original price × 100. The ₹2,000 → ₹800
            example is illustrative, not a pricing rule. Savings on StudySwap listings are based on the
            seller-reported original price, so we label them as estimates.
          </p>
        </div>
        <div className="card grid gap-6 p-6 sm:grid-cols-2 md:p-8">
          <div className="space-y-4">
            <NumField label="Original price (₹)" value={original} onChange={setOriginal} />
            <NumField label="AI-recommended price (₹)" value={price} onChange={setPrice} />
            <NumField label="Your budget (₹)" value={budget} onChange={setBudget} />
          </div>
          <div className="flex flex-col justify-center rounded-2xl bg-forest-soft p-6">
            {s ? (
              <>
                <p className="text-sm font-semibold text-forest">Estimated savings</p>
                <p className="font-display text-5xl font-semibold text-forest">{inr(Math.max(0, s.savings))}</p>
                <p className="mt-1 text-lg font-semibold">{Math.max(0, s.discountPct).toFixed(0)}% off</p>
                {s.needsReview && (
                  <p className="mt-3 text-xs font-semibold text-brick">
                    This price is above the original or implausibly low — it would be sent for review.
                  </p>
                )}
                <p className={`mt-4 rounded-lg px-3 py-2 text-sm font-semibold ${price <= budget ? 'bg-white text-forest' : 'bg-brick-soft text-brick'}`}>
                  {price <= budget ? '✓ Fits your budget' : `${inr(price - budget)} over your budget`}
                </p>
              </>
            ) : (
              <p className="text-sm text-brick">Enter prices greater than ₹0 to calculate savings.</p>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}

function NumField({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  const id = label.replace(/\W/g, '')
  return (
    <div>
      <label htmlFor={id} className="field-label">{label}</label>
      <input
        id={id}
        type="number"
        min={0}
        inputMode="numeric"
        className="field"
        value={Number.isFinite(value) ? value : ''}
        onChange={(e) => onChange(e.target.valueAsNumber)}
      />
    </div>
  )
}

function HowItWorks() {
  const sell = ['List your book with photos and details', 'Accept the AI-recommended price', 'Get contacted by buyers — share details only when you choose']
  const buy = ['Search or browse by exam and edition', 'Compare price, condition and savings', 'Not listed? Post a Free or Premium request']
  return (
    <section className="mx-auto mt-24 max-w-7xl px-5" aria-labelledby="how-h">
      <h2 id="how-h" className="text-center text-3xl md:text-4xl">How StudySwap works</h2>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        {[
          { h: 'For sellers', items: sell, cta: { to: '/sell' as const, label: 'Sell a book' } },
          { h: 'For buyers', items: buy, cta: { to: '/books' as const, label: 'Browse books' } },
        ].map((col) => (
          <div key={col.h} className="card p-8">
            <h3 className="text-2xl">{col.h}</h3>
            <ol className="mt-6 space-y-4">
              {col.items.map((it, i) => (
                <li key={it} className="flex gap-4">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-forest-soft font-bold text-forest">{i + 1}</span>
                  <span className="pt-1">{it}</span>
                </li>
              ))}
            </ol>
            <Link to={col.cta.to} className="btn-ghost mt-8">{col.cta.label}</Link>
          </div>
        ))}
      </div>
      <p className="mx-auto mt-6 max-w-2xl text-center text-xs text-ink-soft">
        StudySwap doesn't collect book payments. Buyers and sellers arrange the exchange directly; the only
        payment on StudySwap is the optional Premium Book Finder fee.
      </p>
    </section>
  )
}
