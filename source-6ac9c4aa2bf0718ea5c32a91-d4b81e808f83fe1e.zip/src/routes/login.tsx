import { useState } from 'react'
import { createFileRoute, Link } from '@tanstack/react-router'
import { Logo } from '@/components/Logo'

export const Route = createFileRoute('/login')({
  head: () => ({ meta: [{ title: 'Log in · StudySwap' }] }),
  component: Login,
})

function Login() {
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [msg, setMsg] = useState('')
  return (
    <div className="mx-auto max-w-md px-5 py-16">
      <div className="card p-8">
        <div className="flex justify-center"><Logo /></div>
        <h1 className="mt-6 text-center text-2xl">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
        <form className="mt-6 space-y-4" onSubmit={(e) => {
          e.preventDefault()
          setMsg('Student accounts open in the next release. Until then you can explore every screen without signing in.')
        }}>
          {mode === 'signup' && (
            <div><label htmlFor="name" className="field-label">Display name</label><input id="name" required className="field" /></div>
          )}
          <div><label htmlFor="email" className="field-label">Email</label><input id="email" type="email" required autoComplete="email" className="field" /></div>
          <div><label htmlFor="pw" className="field-label">Password</label><input id="pw" type="password" required minLength={8} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} className="field" /></div>
          <button className="btn-primary w-full" type="submit">{mode === 'login' ? 'Log in' : 'Sign up'}</button>
        </form>
        {msg && <p role="status" className="mt-4 rounded-xl bg-marigold-soft p-3 text-sm text-[#6b470d]">{msg}</p>}
        <p className="mt-6 text-center text-sm text-ink-soft">
          {mode === 'login' ? 'New to StudySwap? ' : 'Already have an account? '}
          <button type="button" className="font-semibold text-forest underline" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setMsg('') }}>
            {mode === 'login' ? 'Create an account' : 'Log in'}
          </button>
        </p>
      </div>
      <p className="mt-6 text-center text-xs text-ink-soft">
        We never show your phone or email to other students without your consent. <Link to="/legal/$page" params={{ page: 'privacy' }} className="underline">Privacy policy</Link>
      </p>
    </div>
  )
}
