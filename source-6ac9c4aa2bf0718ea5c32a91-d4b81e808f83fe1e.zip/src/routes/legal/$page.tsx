import { createFileRoute, notFound } from '@tanstack/react-router'
import { finderSettings } from '@/data/fixtures'

const pages: Record<string, { title: string; body: Array<[string, string]> }> = {
  contact: {
    title: 'Contact us',
    body: [
      ['Support', 'Questions about a listing, request or payment? Contact the StudySwap team at the support address published on this page once the service launches. Include your request or listing ID.'],
      ['Report a problem', 'Use “Report listing” on any book page to flag misleading or suspicious listings. Moderators review every report.'],
    ],
  },
  privacy: {
    title: 'Privacy policy',
    body: [
      ['What we collect', 'Account email, display name, optional city and preferred contact method, your listings, requests and offers, and payment references for Premium requests. We never store card details — payments are processed by our payment provider.'],
      ['Your contact details', 'Your phone number or email is never shown to other students unless you explicitly choose to share it in a conversation.'],
      ['AI pricing', 'Book details you submit are sent to an AI model to recommend a price. We store the inputs, result and the model version for auditing.'],
      ['Your choices', 'You can edit or delete your listings and request deletion of your account at any time.'],
    ],
  },
  terms: {
    title: 'Terms of use',
    body: [
      ['The marketplace', 'StudySwap connects students buying and selling used books. Transactions for books happen directly between buyer and seller; StudySwap does not collect book payments.'],
      ['Pricing', 'Listing prices are recommended by StudySwap’s AI pricing service and accepted by the seller. Prices marked “estimated” are based on limited evidence.'],
      ['Conduct', 'Listings must honestly describe the book. Misleading listings, spam and harassment lead to removal and account suspension.'],
    ],
  },
  refunds: {
    title: 'Refund policy',
    body: [
      ['Premium Book Finder fee', `The Premium fee (currently ₹${finderSettings.premiumFee}) pays for priority matching for ${finderSettings.matchingDays} days. It is not a payment for the book and does not guarantee the book will be found.`],
      ['When you get a refund', `If no seller offer is received within the ${finderSettings.matchingDays}-day matching period, the request moves to “No Match” and you can request a full refund of the Premium fee. Refunds are returned to the original payment method.`],
      ['Cancellations', 'If you cancel before any seller responds, you may request a refund. Once you have received offers, the fee is non-refundable.'],
      ['Book purchases', 'Book purchases are arranged between students, so StudySwap cannot refund the price of a book.'],
    ],
  },
}

export const Route = createFileRoute('/legal/$page')({
  loader: ({ params }) => {
    const p = pages[params.page]
    if (!p) throw notFound()
    return p
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? 'Policy'} · StudySwap` }] }),
  component: Legal,
})

function Legal() {
  const p = Route.useLoaderData()
  return (
    <article className="mx-auto max-w-3xl px-5 py-14">
      <p className="eyebrow">StudySwap</p>
      <h1 className="mt-2 text-4xl">{p.title}</h1>
      <p className="mt-3 rounded-xl bg-marigold-soft p-3 text-xs text-[#6b470d]">Draft policy for the preview release — to be reviewed before launch.</p>
      <div className="mt-8 space-y-8">
        {p.body.map(([h, t]) => (
          <section key={h}><h2 className="text-xl">{h}</h2><p className="mt-2 leading-relaxed text-ink-soft">{t}</p></section>
        ))}
      </div>
    </article>
  )
}
