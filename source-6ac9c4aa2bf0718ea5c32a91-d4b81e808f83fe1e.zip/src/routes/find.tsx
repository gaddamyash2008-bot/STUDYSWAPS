import { useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { Crown, Search, Check, Info, ArrowRight, Clock, ShieldCheck, Sparkles, Inbox } from 'lucide-react'
import { categories, finderSettings, type CategoryId, type Condition } from '@/data/fixtures'
import { findMatches, type Match } from '@/lib/matching'
import { calculateSavings, inr } from '@/lib/pricing'
import { BookCover } from '@/components/BookCover'
import { ConditionBadge, SampleTag } from '@/components/Badges'

export const Route = createFileRoute('/find')({
  validateSearch: (s: Record<string, unknown>): { title?: string } => ({
    title: typeof s.title === 'string' && s.title ? s.title : undefined,
  }),
  head: () => ({ meta: [{ title: 'Premium Book Finder · StudySwap' }] }),
  component: Find,
})

type Tier = 'Free' | 'Premium'

function Find() {
  const { title: initialTitle } = Route.useSearch()
  const [tier, setTier] = useState<Tier>('Free')
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [result, setResult] = useState<{ matches: Array<Match>; budget: number; tier: Tier; title: string } | null>(null)
  const [submitting, setSubmitting] = useState(false)
  const [ack, setAck] = useState(false)

  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (submitting) return
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>
    const errs: Record<string, string> = {}
    if ((f.title ?? '').trim().length < 2) errs.title = 'Enter the book title you need.'
    if (f.isbn && !/^(97[89])?\d{9}[\dX]$/i.test(f.isbn.replace(/[-\s]/g, ''))) errs.isbn = 'ISBN should be 10 or 13 digits.'
    const budget = Number(f.budget)
    if (!(budget > 0)) errs.budget = 'Enter a maximum budget above ₹0.'
    if (tier === 'Premium' && !ack) errs.ack = 'Please confirm you have read the Premium terms.'
    setErrors(errs)
    if (Object.keys(errs).length) return
    setSubmitting(true)
    setTimeout(() => {
      setResult({
        tier,
        budget,
        title: f.title,
        matches: findMatches({
          title: f.title, author: f.author, isbn: f.isbn, edition: f.edition,
          category: f.category as CategoryId, condition: f.condition as Condition | 'Any',
          maxBudget: budget, city: f.city,
        }).slice(0, 6),
      })
      setSubmitting(false)
      requestAnimationFrame(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth' }))
    }, 900)
  }

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <p className="eyebrow">Premium Book Finder</p>
      <h1 className="mt-2 max-w-2xl text-3xl md:text-4xl">Tell us the book you need. We'll match it against every listing.</h1>
      <p className="mt-3 max-w-2xl text-ink-soft">
        Free requests are matched against available listings. Premium requests get priority matching and wider seller alerts
        for {finderSettings.matchingDays} days.
      </p>

      <form onSubmit={submit} noValidate className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="card grid gap-4 p-6 sm:grid-cols-2 md:p-8">
          <Field label="Book title *" err={errors.title} className="sm:col-span-2"><input name="title" defaultValue={initialTitle} className="field" placeholder="e.g. Problems in General Physics" /></Field>
          <Field label="Author (if known)"><input name="author" className="field" /></Field>
          <Field label="ISBN (if known)" err={errors.isbn}><input name="isbn" className="field" inputMode="numeric" /></Field>
          <Field label="Required edition"><input name="edition" className="field" placeholder="e.g. 7th, 2024" /></Field>
          <Field label="Publication year"><input name="year" type="number" className="field" /></Field>
          <Field label="Exam category">
            <select name="category" className="field" defaultValue="">
              <option value="">Any</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="Preferred condition">
            <select name="condition" className="field" defaultValue="Any">
              <option value="Any">Any condition</option><option value="Like New">Like New</option><option value="Good">Good or better</option><option value="Acceptable">Acceptable or better</option>
            </select>
          </Field>
          <Field label="Maximum budget (₹) *" err={errors.budget}><input name="budget" type="number" min={1} className="field" placeholder="500" /></Field>
          <Field label="Preferred city / delivery"><input name="city" className="field" placeholder="e.g. Delhi, or 'shipping'" /></Field>
          <Field label="Additional notes" className="sm:col-span-2"><textarea name="notes" className="field min-h-20" maxLength={500} placeholder="Anything sellers should know" /></Field>
        </div>

        <aside className="space-y-4">
          <fieldset className="space-y-3">
            <legend className="sr-only">Request type</legend>
            <TierCard active={tier === 'Free'} onSelect={() => setTier('Free')} title="Free Request" price="₹0" icon={<Search size={18} />}
              points={['Standard matching against listings', 'Request status tracking', 'Review available matches']} />
            <TierCard active={tier === 'Premium'} onSelect={() => setTier('Premium')} title="Premium Request" price={inr(finderSettings.premiumFee)} icon={<Crown size={18} />} highlight
              points={['Priority matching queue', 'Wider alerts to opted-in sellers', 'Priority seller responses', 'Offer comparison & notifications']} />
          </fieldset>

          {tier === 'Premium' && (
            <div className="rounded-2xl border border-marigold bg-marigold-soft p-4 text-sm">
              <p className="font-semibold">Before you pay</p>
              <ul className="mt-2 space-y-1 text-[#6b470d]">
                <li>• Fee: {inr(finderSettings.premiumFee)} (incl. applicable taxes) — for the matching service, not the book.</li>
                <li>• Matching period: {finderSettings.matchingDays} days.</li>
                <li>• We can't guarantee the book will be found.</li>
                <li>• No match in {finderSettings.matchingDays} days? You're eligible for a refund — see the <Link to="/legal/$page" params={{ page: 'refunds' }} className="underline">refund policy</Link>.</li>
              </ul>
              <label className="mt-3 flex gap-2">
                <input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} className="mt-1 accent-forest" />
                <span>I understand these terms.</span>
              </label>
              {errors.ack && <p className="field-error">{errors.ack}</p>}
            </div>
          )}

          <button type="submit" className="btn-primary w-full" disabled={submitting}>
            {submitting ? 'Matching…' : tier === 'Premium' ? `Continue to payment · ${inr(finderSettings.premiumFee)}` : 'Submit free request'}
          </button>
        </aside>
      </form>

      {result && <Results {...result} />}
    </div>
  )
}

function Results({ matches, budget, tier, title }: { matches: Array<Match>; budget: number; tier: Tier; title: string }) {
  return (
    <section id="results" className="mt-14 scroll-mt-24" aria-live="polite">
      {tier === 'Premium' && (
        <div className="mb-6 flex gap-3 rounded-2xl border border-line bg-card p-5">
          <ShieldCheck className="shrink-0 text-forest" />
          <div className="text-sm">
            <p className="font-semibold">Payment step — not yet connected</p>
            <p className="mt-1 text-ink-soft">
              In the live product your request is saved as <b>Awaiting Payment</b>, you pay through Razorpay, and Premium matching
              starts only after our server verifies the payment. No payment was taken in this preview. Here's what standard matching found right now:
            </p>
          </div>
        </div>
      )}
      <div className="flex flex-wrap items-center gap-3">
        <h2 className="text-2xl md:text-3xl">{matches.length ? `${matches.length} possible match${matches.length === 1 ? '' : 'es'}` : 'No matches yet'}</h2>
        <SampleTag />
      </div>
      <p className="mt-1 text-sm text-ink-soft">for “{title}” · budget {inr(budget)}</p>

      {matches.length ? (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {matches.map(({ listing: l, reasons }) => {
            const s = calculateSavings(l.originalPrice, l.price)
            const fits = l.price <= budget
            return (
              <Link key={l.id} to="/books/$bookId" params={{ bookId: l.id }} className="card flex gap-4 p-4 transition hover:border-forest/50">
                <div className="w-24 shrink-0"><BookCover title={l.title} author={l.author} category={l.category} size="sm" /></div>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold leading-snug">{l.title}</p>
                  <p className="text-xs text-ink-soft">{l.author} · {l.edition} · {l.city}</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    <ConditionBadge condition={l.condition} />
                    {reasons.slice(0, 3).map((r) => <span key={r} className="chip bg-paper-deep text-ink-soft"><Check size={11} />{r}</span>)}
                  </div>
                  <div className="mt-3 flex flex-wrap items-baseline gap-2">
                    <span className="text-lg font-bold">{inr(l.price)}</span>
                    {s && <span className="text-xs text-ink-soft">est. save {inr(s.savings)}</span>}
                    <span className={`chip ml-auto ${fits ? 'bg-forest-soft text-forest' : 'bg-brick-soft text-brick'}`}>{fits ? 'Fits budget' : `${inr(l.price - budget)} over`}</span>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      ) : (
        <div className="card mt-6 flex flex-col items-center px-6 py-14 text-center">
          <Inbox size={36} className="text-ink-soft" />
          <p className="mt-4 max-w-md text-ink-soft">
            Nothing listed matches right now. Once requests are saved, we keep matching new listings and
            {tier === 'Premium' ? ' alert opted-in sellers straight away' : ' notify you when one appears'}.
          </p>
        </div>
      )}

      <div className="mt-8 grid gap-3 sm:grid-cols-3">
        {[
          { i: Sparkles, t: 'Normalised matching', d: 'Exact ISBN first, then title, author, edition, condition, budget and city.' },
          { i: Clock, t: `${finderSettings.matchingDays}-day window`, d: 'Premium requests keep searching and alerting sellers for the full period.' },
          { i: Info, t: 'Real offers only', d: 'Every offer is an actual listing or seller response, AI-priced like any other.' },
        ].map((x) => (
          <div key={x.t} className="rounded-2xl bg-paper-deep/70 p-4 text-sm">
            <x.i size={18} className="text-forest" />
            <p className="mt-2 font-semibold">{x.t}</p>
            <p className="mt-1 text-ink-soft">{x.d}</p>
          </div>
        ))}
      </div>
      <Link to="/dashboard" className="btn-ghost mt-8">See how requests are tracked <ArrowRight size={16} /></Link>
    </section>
  )
}

function TierCard(p: { active: boolean; onSelect: () => void; title: string; price: string; icon: React.ReactNode; points: Array<string>; highlight?: boolean }) {
  return (
    <label className={`block cursor-pointer rounded-2xl border-2 p-5 transition ${p.active ? (p.highlight ? 'border-marigold bg-marigold-soft' : 'border-forest bg-forest-soft') : 'border-line bg-card hover:border-forest/40'}`}>
      <input type="radio" name="tier" checked={p.active} onChange={p.onSelect} className="sr-only" />
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 font-semibold">{p.icon}{p.title}</span>
        <span className="font-display text-xl font-semibold">{p.price}</span>
      </div>
      <ul className="mt-3 space-y-1 text-sm text-ink-soft">
        {p.points.map((x) => <li key={x} className="flex gap-2"><Check size={14} className="mt-0.5 shrink-0 text-forest" />{x}</li>)}
      </ul>
    </label>
  )
}

function Field({ label, err, className = '', children }: { label: string; err?: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={className}>
      <label className="field-label">{label}<span className="mt-1.5 block font-normal">{children}</span></label>
      {err && <p className="field-error">{err}</p>}
    </div>
  )
}
