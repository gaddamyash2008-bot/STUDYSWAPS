import { useState } from 'react'
import { Link, createFileRoute, notFound } from '@tanstack/react-router'
import { ArrowLeft, MapPin, Truck, Calendar, Flag, MessageCircle, Info, Lock } from 'lucide-react'
import { getCategory, getListing, listings } from '@/data/fixtures'
import { BookCover } from '@/components/BookCover'
import { BookCard } from '@/components/BookCard'
import { ConditionBadge, ConfidenceBadge, SampleTag } from '@/components/Badges'
import { calculateSavings, inr } from '@/lib/pricing'

export const Route = createFileRoute('/books/$bookId')({
  loader: ({ params }) => {
    const book = getListing(params.bookId)
    if (!book) throw notFound()
    return book
  },
  head: ({ loaderData }) => ({ meta: [{ title: `${loaderData?.title ?? 'Book'} · StudySwap` }] }),
  component: BookDetail,
})

function BookDetail() {
  const book = Route.useLoaderData()
  const s = calculateSavings(book.originalPrice, book.price)
  const [panel, setPanel] = useState<'none' | 'contact' | 'report'>('none')
  const [reported, setReported] = useState(false)
  const similar = listings.filter((l) => l.category === book.category && l.id !== book.id && l.status === 'Active').slice(0, 4)

  return (
    <div className="mx-auto max-w-7xl px-5 py-10">
      <Link to="/books" className="inline-flex items-center gap-1 text-sm font-semibold text-forest hover:underline">
        <ArrowLeft size={14} /> Back to browse
      </Link>

      <div className="mt-6 grid gap-10 lg:grid-cols-[minmax(0,380px)_1fr]">
        <div className="mx-auto w-full max-w-sm">
          <BookCover title={book.title} author={book.author} category={book.category} size="lg" />
          <p className="mt-3 text-center text-xs text-ink-soft">Seller photos appear here once uploads are live.</p>
        </div>

        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="chip bg-paper-deep text-ink-soft">{getCategory(book.category).name}</span>
            <ConditionBadge condition={book.condition} />
            {book.status !== 'Active' && <span className="chip bg-ink text-white">{book.status}</span>}
            <SampleTag />
          </div>
          <h1 className="mt-3 text-3xl md:text-4xl">{book.title}</h1>
          <p className="mt-2 text-ink-soft">by {book.author}</p>

          <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 text-sm sm:grid-cols-3">
            <Meta k="Edition" v={book.edition} />
            <Meta k="Published" v={String(book.publicationYear)} />
            <Meta k="ISBN" v={book.isbn ?? 'Not provided'} />
            <Meta k="Wear" v={book.wear} />
            <Meta k="Location" v={<span className="inline-flex items-center gap-1"><MapPin size={13} />{book.city}</span>} />
            <Meta k="Exchange" v={<span className="inline-flex items-center gap-1"><Truck size={13} />{book.exchange}</span>} />
          </dl>

          <div className="card mt-8 p-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-sm font-semibold text-ink-soft">AI-recommended price</p>
                <p className="mt-1 flex items-baseline gap-3">
                  <span className="font-display text-4xl font-semibold">{inr(book.price)}</span>
                  <span className="text-ink-soft line-through">{inr(book.originalPrice)}</span>
                </p>
                <p className="mt-1 text-xs text-ink-soft">
                  Estimated range {inr(book.priceRange[0])}–{inr(book.priceRange[1])}
                </p>
              </div>
              <ConfidenceBadge confidence={book.confidence} evidence={book.evidence} />
            </div>

            {s && (
              <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl bg-forest-soft p-4">
                <div>
                  <p className="text-xs font-semibold text-forest">Estimated savings</p>
                  <p className="font-display text-2xl font-semibold text-forest">{inr(s.savings)}</p>
                </div>
                <div>
                  <p className="text-xs font-semibold text-forest">Discount</p>
                  <p className="font-display text-2xl font-semibold text-forest">{s.discountPct.toFixed(0)}%</p>
                </div>
                <p className="col-span-2 flex gap-1.5 text-xs text-forest/80">
                  <Info size={14} className="shrink-0" /> Based on the seller-reported original price — an estimate, not verified.
                </p>
              </div>
            )}

            <div className="mt-5">
              <p className="text-sm font-semibold">Why this price</p>
              <ul className="mt-2 space-y-1 text-sm text-ink-soft">
                {book.pricingFactors.map((f) => <li key={f}>• {f}</li>)}
              </ul>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <button type="button" className="btn-primary" disabled={book.status !== 'Active'} onClick={() => setPanel(panel === 'contact' ? 'none' : 'contact')}>
                <MessageCircle size={16} /> Contact seller
              </button>
              <button type="button" className="btn-ghost" onClick={() => setPanel(panel === 'report' ? 'none' : 'report')}>
                <Flag size={16} /> Report listing
              </button>
            </div>

            {panel === 'contact' && (
              <div className="mt-4 rounded-xl border border-line bg-paper p-4 text-sm">
                <p className="flex items-center gap-2 font-semibold"><Lock size={14} /> Contact is consent-based</p>
                <p className="mt-1 text-ink-soft">
                  You'll message {book.sellerName} in-app. Their phone or email is only shared if they choose to.
                  Log in to send a message.
                </p>
                <Link to="/login" className="btn-primary mt-3 !py-2">Log in to message</Link>
              </div>
            )}
            {panel === 'report' && (
              <form className="mt-4 rounded-xl border border-line bg-paper p-4 text-sm" onSubmit={(e) => { e.preventDefault(); setReported(true) }}>
                {reported ? (
                  <p className="font-semibold text-forest" role="status">Thanks — this preview recorded your report locally. Reports reach moderators once accounts launch.</p>
                ) : (
                  <>
                    <label htmlFor="reason" className="field-label">What's wrong with this listing?</label>
                    <select id="reason" className="field" required defaultValue="">
                      <option value="" disabled>Choose a reason</option>
                      <option>Misleading condition or photos</option>
                      <option>Wrong edition</option>
                      <option>Suspected scam</option>
                      <option>Other</option>
                    </select>
                    <button className="btn-primary mt-3 !py-2" type="submit">Submit report</button>
                  </>
                )}
              </form>
            )}
          </div>

          <div className="mt-6 text-sm text-ink-soft">
            <p className="font-semibold text-ink">Seller's notes</p>
            <p className="mt-1">{book.description}</p>
            <p className="mt-3 flex items-center gap-1 text-xs"><Calendar size={12} /> Listed {new Date(book.listedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })} by {book.sellerName}</p>
          </div>
          <p className="mt-6 rounded-xl bg-marigold-soft p-4 text-xs text-[#6b470d]">
            StudySwap doesn't take payment for books. Meet in a public place or use tracked shipping, and inspect the book before paying the seller.
          </p>
        </div>
      </div>

      {similar.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl">More {getCategory(book.category).name} books</h2>
          <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {similar.map((b) => <BookCard key={b.id} book={b} />)}
          </div>
        </section>
      )}
    </div>
  )
}

function Meta({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wide text-ink-soft">{k}</dt>
      <dd className="mt-0.5 font-medium">{v}</dd>
    </div>
  )
}
