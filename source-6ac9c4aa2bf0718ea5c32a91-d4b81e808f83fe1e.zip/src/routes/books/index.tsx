import { useMemo } from 'react'
import { Link, createFileRoute, useNavigate } from '@tanstack/react-router'
import { Search, SlidersHorizontal, X, BookX } from 'lucide-react'
import { categories, listings, type CategoryId, type Condition } from '@/data/fixtures'
import { BookCard } from '@/components/BookCard'
import { SampleTag } from '@/components/Badges'

type Sort = 'relevance' | 'price-asc' | 'price-desc' | 'newest'
interface BrowseSearch {
  q?: string
  category?: CategoryId
  condition?: Condition
  maxPrice?: number
  city?: string
  edition?: string
  sort?: Sort
}

const catIds = categories.map((c) => c.id) as Array<string>
const conditions: Array<Condition> = ['Like New', 'Good', 'Acceptable']
const sorts: Array<Sort> = ['relevance', 'price-asc', 'price-desc', 'newest']

export const Route = createFileRoute('/books/')({
  validateSearch: (s: Record<string, unknown>): BrowseSearch => ({
    q: typeof s.q === 'string' && s.q ? s.q : undefined,
    category: catIds.includes(s.category as string) ? (s.category as CategoryId) : undefined,
    condition: conditions.includes(s.condition as Condition) ? (s.condition as Condition) : undefined,
    maxPrice: Number(s.maxPrice) > 0 ? Number(s.maxPrice) : undefined,
    city: typeof s.city === 'string' && s.city ? s.city : undefined,
    edition: typeof s.edition === 'string' && s.edition ? s.edition : undefined,
    sort: sorts.includes(s.sort as Sort) ? (s.sort as Sort) : undefined,
  }),
  head: () => ({ meta: [{ title: 'Browse books · StudySwap' }] }),
  component: Browse,
})

const cities = [...new Set(listings.map((l) => l.city))].sort()
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '')

function Browse() {
  const search = Route.useSearch()
  const navigate = useNavigate({ from: '/books/' })
  const set = (patch: Partial<BrowseSearch>) =>
    navigate({ search: (prev) => ({ ...prev, ...patch }), replace: true })

  const results = useMemo(() => {
    const q = search.q?.toLowerCase().trim()
    const terms = q ? q.split(/\s+/) : []
    let out = listings
      .filter((l) => l.status === 'Active' || l.status === 'Reserved')
      .map((l) => {
        const hay = `${l.title} ${l.author} ${l.isbn ?? ''} ${l.edition} ${l.description} ${categories.find((c) => c.id === l.category)?.name}`.toLowerCase()
        const isbnHit = q && l.isbn && norm(l.isbn) === norm(q)
        const score = isbnHit ? 100 : terms.filter((t) => hay.includes(t) || norm(hay).includes(norm(t))).length
        return { l, score }
      })
      .filter(({ l, score }) => {
        if (terms.length && score < Math.ceil(terms.length * 0.6)) return false
        if (search.category && l.category !== search.category) return false
        if (search.condition && l.condition !== search.condition) return false
        if (search.maxPrice && l.price > search.maxPrice) return false
        if (search.city && l.city !== search.city) return false
        if (search.edition && !l.edition.toLowerCase().includes(search.edition.toLowerCase())) return false
        return true
      })
    const sort = search.sort ?? 'relevance'
    out = [...out].sort((a, b) => {
      if (sort === 'price-asc') return a.l.price - b.l.price
      if (sort === 'price-desc') return b.l.price - a.l.price
      if (sort === 'newest') return b.l.listedAt.localeCompare(a.l.listedAt)
      return b.score - a.score || b.l.listedAt.localeCompare(a.l.listedAt)
    })
    return out.map((r) => r.l)
  }, [search])

  const active = Object.entries(search).filter(([k, v]) => v !== undefined && k !== 'sort')

  return (
    <div className="mx-auto max-w-7xl px-5 py-10">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-3xl md:text-4xl">Browse books</h1>
        <SampleTag />
      </div>

      <form
        role="search"
        className="mt-6 flex items-center gap-2 rounded-full border border-line bg-white p-1.5"
        onSubmit={(e) => {
          e.preventDefault()
          const v = new FormData(e.currentTarget).get('q')?.toString().trim()
          set({ q: v || undefined })
        }}
      >
        <Search className="ml-3 text-ink-soft" size={18} aria-hidden />
        <label htmlFor="q" className="sr-only">Search</label>
        <input key={search.q} id="q" name="q" defaultValue={search.q} placeholder="Search title, author, ISBN or keyword" className="min-w-0 flex-1 bg-transparent py-2 text-sm outline-none" />
        <button className="btn-primary" type="submit">Search</button>
      </form>

      <div className="mt-8 grid gap-8 lg:grid-cols-[250px_1fr]">
        <aside className="card h-fit space-y-5 p-5" aria-label="Filters">
          <p className="flex items-center gap-2 text-sm font-bold"><SlidersHorizontal size={16} /> Filters</p>
          <Select label="Category" value={search.category ?? ''} onChange={(v) => set({ category: (v || undefined) as CategoryId })}
            options={[['', 'All categories'], ...categories.map((c) => [c.id, c.name] as [string, string])]} />
          <Select label="Condition" value={search.condition ?? ''} onChange={(v) => set({ condition: (v || undefined) as Condition })}
            options={[['', 'Any condition'], ...conditions.map((c) => [c, c] as [string, string])]} />
          <Select label="Location" value={search.city ?? ''} onChange={(v) => set({ city: v || undefined })}
            options={[['', 'All cities'], ...cities.map((c) => [c, c] as [string, string])]} />
          <div>
            <label htmlFor="edition" className="field-label">Edition</label>
            <input id="edition" key={search.edition} defaultValue={search.edition} placeholder="e.g. 2024, 7th"
              className="field" onBlur={(e) => set({ edition: e.target.value.trim() || undefined })}
              onKeyDown={(e) => e.key === 'Enter' && set({ edition: e.currentTarget.value.trim() || undefined })} />
          </div>
          <div>
            <label htmlFor="max" className="field-label">Max price: {search.maxPrice ? `₹${search.maxPrice}` : 'Any'}</label>
            <input id="max" type="range" min={100} max={1000} step={50} value={search.maxPrice ?? 1000}
              onChange={(e) => set({ maxPrice: e.target.valueAsNumber >= 1000 ? undefined : e.target.valueAsNumber })}
              className="w-full accent-forest" />
          </div>
          {active.length > 0 && (
            <button type="button" className="btn-ghost w-full" onClick={() => navigate({ search: {}, replace: true })}>
              Clear all filters
            </button>
          )}
        </aside>

        <div>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-ink-soft" aria-live="polite">
              <b className="text-ink">{results.length}</b> book{results.length === 1 ? '' : 's'} found
            </p>
            <div className="flex flex-wrap items-center gap-2">
              {active.map(([k, v]) => (
                <button key={k} type="button" onClick={() => set({ [k]: undefined } as Partial<BrowseSearch>)} className="chip bg-forest-soft text-forest hover:bg-forest hover:text-white">
                  {k === 'category' ? categories.find((c) => c.id === v)?.name : k === 'maxPrice' ? `≤ ₹${v}` : String(v)} <X size={12} />
                </button>
              ))}
              <label htmlFor="sort" className="sr-only">Sort</label>
              <select id="sort" value={search.sort ?? 'relevance'} onChange={(e) => set({ sort: e.target.value as Sort })} className="field !w-auto !py-2">
                <option value="relevance">Most relevant</option>
                <option value="price-asc">Price: low to high</option>
                <option value="price-desc">Price: high to low</option>
                <option value="newest">Newest listings</option>
              </select>
            </div>
          </div>

          {results.length ? (
            <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
              {results.map((b) => <BookCard key={b.id} book={b} />)}
            </div>
          ) : (
            <div className="card mt-5 flex flex-col items-center px-6 py-16 text-center">
              <BookX size={40} className="text-ink-soft" />
              <h2 className="mt-4 text-2xl">No books match yet</h2>
              <p className="mt-2 max-w-md text-ink-soft">
                Try fewer filters — or let sellers come to you. Post a request and we'll match it against new listings.
              </p>
              <Link to="/find" search={{ title: search.q }} className="btn-primary mt-6">Request this book</Link>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function Select({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: Array<[string, string]> }) {
  const id = `f-${label}`
  return (
    <div>
      <label htmlFor={id} className="field-label">{label}</label>
      <select id={id} className="field" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </div>
  )
}
